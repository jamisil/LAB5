package documin;

//import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class DocumentoTest {
	//private DocumentoController sistema;
	//private Documento doc;
	@BeforeEach
	void setUp() {
//		DocumentoController sistema = new DocumentoController(); 
	}

	@Test
	void criaDocumentosemtamanho() {
		Documento doc = new Documento("Linda");
		assertEquals("[]",doc.representacaoDocumento());
	}
	
	@Test
	void criaDocumentocomtamanho() {
		Documento doc = new Documento("Lucas",2);
		assertEquals("[]", doc.toString());
	}
	@Test
	void criaDocumentosemTitulo() {
		try {
			new Documento("");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (IllegalArgumentException e) {
			assertEquals("Dados Inválidos", e.getMessage());
		}
	}
	@Test
	void criaDocumentosemTituloecomTamanho() {
		try {
			new Documento("",4);
			fail("Deveria ter lançado excecao de dados inválidos");
		} catch(IllegalArgumentException e) {
			assertEquals("Dados Inválidos", e.getMessage());
		}
	}
	
	@Test
	void numeroelemento() {
		Documento doc = new Documento("facas",8);
		assertEquals(0,doc.getnumeroelementos());
	}
	@Test
	void numeroelementoadiciona() {
		Documento doc = new Documento("facas");
		assertEquals("[]",doc.toString());
	}
	
	@Test
	void getnumeroelementos() {
		Documento doc = new Documento("ecossitema");
		doc.criaLista("Exemplo | de lista", 2, "|", "-");
		doc.criaTitulo("Receitas", 1, 4, false);
		assertEquals(2,doc.getnumeroelementos());
	}

}
