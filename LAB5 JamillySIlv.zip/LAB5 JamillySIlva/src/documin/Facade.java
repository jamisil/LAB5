package documin;

//import java.util.Arrays;

public class Facade {

	private DocumentoController documentoController;

	public Facade() {
		this.documentoController = new DocumentoController();
	}

	public boolean criarDocumento(String titulo) {
		return this.documentoController.criarDocumento(titulo);
	}

	public boolean criarDocumento(String titulo, int tamanho) {
		return this.documentoController.criarDocumento(titulo, tamanho);
	}

	public void removerDocumento(String titulo) {
		this.documentoController.removerDocumento(titulo);
	}

	public int contarElementos(String titulo) {
		return this.documentoController.contaelementos(titulo);

	}

	public String[] exibirDocumento(String titulo) {
		return (this.exibirDocumento(titulo));//Arrays.toString
	}
	
	public int criarTexto(String titulo, String valor, int prioridade) {
		return this.documentoController.criarTexto(titulo, valor, prioridade);
	}
	
	public int criarLista(String titulo, String valor, int prioridade, String separador, String charLista) {
		return this.documentoController.criarLista(titulo,valor,prioridade,separador,charLista);
	}
	public int criarTermos(String titulo, String valor, int prioridade, String separador, String ordem) {
		return this.documentoController.criarTermos(titulo, valor, prioridade, separador, ordem);
	}
	public String pegarRepresentacaoCompleta(String titulo,int elementoposicao) {
		return this.documentoController.pegarRepresentacaoCompleta(titulo, elementoposicao);
	}
	public String pegarRepresentacaoResumida(String titulo,int elementoposicao) {
		return this.documentoController.pegarRepresentacaoResumida(titulo, elementoposicao);
	}
	public boolean apagarElemento(String titulo, int elementoposicao) {
		return this.documentoController.apagarElemento(titulo, elementoposicao);
	}
	public void moverParaCima(String titulo, int elementoposicao) {
		this.documentoController.moverParaCima(titulo, elementoposicao);
	}
	public void moverParaBaixo(String titulo, int elementoposicao) {
		this.documentoController.moverParaBaixo(titulo, elementoposicao);
	}


}