package documin;

public abstract class Elementop {
	private String relevancia;
	private String propriedades;
}
