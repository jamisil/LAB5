package documin;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.HashMap;

public class Termos implements Elemento {
	
	private String valor;
	private int prioridade;
	private String separador;
	private HashMap<String,String> propriedades;
	private String ordem;
	
	public Termos(String valor,int prioridade,String separador,  String ordem) {
		if (valor.isEmpty() || prioridade <= 0 || separador.isEmpty() || ordem.isEmpty()) {
			throw new IllegalArgumentException();
		}
		this.valor = valor;
		this.prioridade = prioridade;
		this.separador = separador;
		this.ordem = ordem;
		this.propriedades = new HashMap <>();
		this.propriedades.put("Propriedades", "Separador (string) + Ordem ('NENHUM', 'ALFABÉTICA', 'TAMANHO')");
		
	}
	
	public int contador() {
		int cont = this.valor.split(separador).length;
		return cont;
	}
	@Override
	public String RepresentacaoCompleta() {
		String[] a = this.valor.split(separador);
		if(this.ordem.toUpperCase() == "ALFABÉTICA") {
			Arrays.sort(a);
		}
		String ordem;
        for (int i = 0; i < contador(); i++) {
            
	}
	
	@Override
	public String RepresentacaoResumida() {
		// TODO Auto-generated method stub
		return null;
	}
}
