package documin;

import java.util.HashMap;

//import java.util.ArrayList;

public class Lista implements Elemento {
	private String valorLista;
	private int prioridade;
	private HashMap <String,String> propriedades;
	private String separador;
	private String charLista;

	public Lista(String valorLista, int prioridade, String separador, String charLista) {
		if (valorLista.isEmpty() || prioridade <= 0 || separador.isEmpty() || charLista.isEmpty()) {
			throw new IllegalArgumentException();
		}
		this.valorLista = valorLista;
		this.prioridade = prioridade;
		this.separador = separador;
		this.charLista = charLista;
		this.propriedades = new HashMap <>();
		this.propriedades.put("Propriedades", "Separador (string)\n"+ "Caractere de Lista (string)\n");
	}

	public String RepresentacaoCompleta() {
		String representacaocompleta = this.charLista + " ";
		representacaocompleta += this.valorLista.replace(separador, "\n-");
		return representacaocompleta;
	}

	public String RepresentacaoResumida() {
		String representacaoresumida = "";
		String representacao = this.valorLista;//.replace(" ", "");
		representacaoresumida += representacao.replace(separador, ",");
		return representacaoresumida;
	}

	@Override
	public String toString() {
		return RepresentacaoResumida();
	}
}
