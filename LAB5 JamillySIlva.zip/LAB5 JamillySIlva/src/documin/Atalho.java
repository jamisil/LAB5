package documin;

import java.util.Arrays;
import java.util.HashMap;

public class Atalho extends Documento implements Elemento {
	
	private double prioridade;
	private String valor; //id documento
	private String representacaoCompleta;
	private String representacaoResumo;
	
	
	public Atalho(String tituloDocReferenciado, double prioridade, String valor, String representacaoCompleta, String representacaoResumida) {
		// fazer exececao is.empty 
		super(tituloDocReferenciado);
			this.prioridade = prioridade;
			this.valor = valor;
			this.representacaoCompleta = representacaoCompleta;
			this.representacaoResumo = representacaoResumida;
		}
		
	



	@Override
	public String RepresentacaoResumida() {
		
		return super.pegarRepresentacaoResumidaAtalho();
	}



	@Override
	public int getPrioridade() {
		return (int)this.prioridade;
	}





	@Override
	public String RepresentacaoCompleta() {
		return super.pegarRepresentacaoCompletaAtalho();
	}


}