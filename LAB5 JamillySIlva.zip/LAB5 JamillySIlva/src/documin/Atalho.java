package documin;

import java.util.Arrays;
import java.util.HashMap;

public class Atalho extends Documento {
	
	private double prioridade;
	private String valor; //id documento
	private String representacaoCompleta;
	private String representacaoResumo;
	
	
	public Atalho(String tituloDocReferenciado) {
		super(titulo);
		if (super.getQuantidadeAtalho() == 0) {
			this.prioridade = super.calculaMedia();
			this.valor = super.getTitulo();
		}
		
	}

	public String RepresentacaoCompleta() {
		String representacao = "";
		if (getElementos().isEmpty()) {
			return representacao;
		}
		for (int i = 0; i <= super.getElementos().size(); i++) {
			String a = this.getElementos().get(i).RepresentacaoCompleta();
			representacao += a;
		}
		return representacao;
	}


}