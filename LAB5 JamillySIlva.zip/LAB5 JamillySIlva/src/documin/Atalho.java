package documin;

import java.util.HashMap;

public class Atalho extends Documento {
	
	private double prioridade;
	private String valor; //id documento
	private String representacaoCompleta;
	private String representacaoResumo;
	
	
	public Atalho(String tituloDocReferenciado) {
		super(tituloDocReferenciado);
		if (super.getQuantidadeAtalho() == 0) {
			this.prioridade = super.calculaMedia();
			this.valor = super.getTitulo();
		//fazer um set	this.representacaoCompleta = e de this.representacaoResumida
		}
		
	}

}