package documin;

/**
 * Representação de Atalho
 * 
 * @author Jamilly
 *
 */
public class Atalho extends Documento implements Elemento {
	/**
	 * @param prioridade            Um double , qual é a média das prioriades dos
	 *                              docReferenciado.
	 * @param valor                 Uma string representando os dados desse
	 *                              elemento.
	 * @param representacaoCompleta String Representação Completa de texto.
	 * @param representacaoResumo   String Representação Resumida de texto.
	 * 
	 */

	private double prioridade;
	private String valor;
	private String representacaoCompleta;
	private String representacaoResumo;

	/**
	 * Constrói um Atalho, a partir de um Doc Referenciado
	 * 
	 * @param tituloDoc             Titulo do documento que terá a seus elementos o
	 *                              Atalho adicionado.
	 * @param prioridade            media das prioridades do elementos do documento
	 *                              referenciado.
	 * @param valor                 String que representa o id do documento, vindo
	 *                              do título do Doc referenciado.
	 * @param representacaoCompleta String Representação Completa de texto.
	 * @param representacaoResumida String Representação Resumida de texto.
	 */
	public Atalho(String tituloDoc, double prioridade, String valor, String representacaoCompleta,
			String representacaoResumida) {
		super(tituloDoc);
		if (prioridade < 0 || valor.isBlank() || representacaoCompleta.isBlank() || prioridade > 5
				|| representacaoResumida.isBlank()) {
			throw new IllegalArgumentException("Dados Inválidos");
		}

		this.prioridade = prioridade;
		this.valor = valor;
		this.representacaoCompleta = representacaoCompleta;
		this.representacaoResumo = representacaoResumida;
	}

	/**
	 * Gera a representação Resumida de Atalho
	 * 
	 * @return String da representação resumida de Atalho
	 * 
	 */
	public String RepresentacaoResumida() {
		String representacao = "";
		for (int i = 0; i < this.getElementos().size(); i++) {
			if (this.getElementos().get(i).getPrioridade() > 3) {
				representacao += this.getElementos().get(i).RepresentacaoResumida();
			}
		}
		return representacao;
	}

	/**
	 * Gera a representação Resumida de Atalho
	 * 
	 * @return String da representação Completa de Atalho.
	 */

	public String RepresentacaoCompleta() {
		String representacao = "";
		for (int i = 0; i < this.getElementos().size(); i++) {
			if (this.getElementos().get(i).getPrioridade() > 3) {
				representacao += this.getElementos().get(i).RepresentacaoCompleta();
			}
		}
		return representacao;
	}

	public double getPrioridade() {
		return this.prioridade;
	}

}