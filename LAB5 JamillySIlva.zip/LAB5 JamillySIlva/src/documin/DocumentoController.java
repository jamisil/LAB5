package documin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.NoSuchElementException;

/**
 * Representação do Controller de Documento, responsável pela administração dos
 * Documentos.
 * 
 * @author Jamilly Venâncio
 *
 */
public class DocumentoController {
	/**
	 * @param documentos HashMap, com chave do tipo String,específica de cada
	 *                   documento, que guarda um Documento.
	 * @param visaoid    Int, id das visões criadas.
	 * @param visoes,    ArrayList das visões cadastradas.
	 */
	private HashMap<String, Documento> documentos;
	private int visaoid;
	private ArrayList<String[]> visoes;

	/**
	 * Constrói um DocumentoController.
	 * 
	 */

	public DocumentoController() {
		this.documentos = new HashMap<String, Documento>();
		this.visoes = new ArrayList<String[]>();
	}

	/**
	 * Retorna se o Documento foi criado ou não.
	 * 
	 * @param titulo  Nome do documento , o qual torna possível sua identificação.
	 * @param tamanho Representa o tamanho dos elementos que podem ser aderidos ao
	 *                Documento.
	 * @return boolean Representa se o Documento foi criado ou não.
	 */
	public boolean criarDocumento(String titulo, int tamanho) {
		Documento documento = new Documento(titulo, tamanho);
		if ((this.documentos.containsKey(titulo) || this.documentos.getClass() == null)) {
			return false;
		}
		this.documentos.put(titulo, documento);
		return true;
	}

	/**
	 * Retorna se o Documento foi criado ou não.
	 * 
	 * @param titulo Nome do documento , o qual torna possível sua identificação.
	 * @return boolean Representa se o Documento foi criado ou não.
	 */

	public boolean criarDocumento(String titulo) {
		Documento documento = new Documento(titulo);
		if ((this.documentos.containsKey(titulo) || this.documentos.getClass() == null)) {
			return false;
		}
		this.documentos.put(titulo, documento);
		return true;
	}

	/**
	 * Remove um Documento pela sua identificação(pelo título).
	 * 
	 * @param titulo Nome do documento(chave que torna possível seu acesso) , o qual
	 *               torna possível sua identificação.
	 */

	public void removerDocumento(String titulo) {
		if (!(this.documentos.containsKey(titulo))) {
			throw new NoSuchElementException("Não existe");
		} else {
			this.documentos.remove(titulo);
		}
	}

	/**
	 * Retorna a quantidade de elementos presentes no Documento.
	 * 
	 * @param titulo Nome do documento , o qual torna possível sua identificação.
	 * @return int Representa a quantidade de elementos no Documento.
	 */

	public int contaelementos(String titulo) {
		if (!(this.documentos.containsKey(titulo))) {
			throw new NoSuchElementException("Não existe");
		}
		return this.documentos.get(titulo).getElementos().size();
	}

	/**
	 * Retorna um array de String, com uma representação de cada elemento inserido
	 * no Documento.
	 * 
	 * @param titulo Nome do documento , o qual torna possível sua identificação.
	 * @return Array de String de cada elemento presente em Documento.
	 */

	public String[] exibirDocumento(String titulo) {
		if (!(this.documentos.containsKey(titulo))) {
			throw new NoSuchElementException("Não existe");
		}
		return this.documentos.get(titulo).representacaoDocumento();
	}

	/**
	 * Retorna a posição ,do elemento criado TEXTO, no Documento.
	 * 
	 * @param titulo     Nome do documento , o qual torna possível sua
	 *                   identificação.
	 * @param valor      Uma string representando os dados desse elemento.
	 * @param prioridade Valor inteiro entre 1-5 (inclusive), indicando elementos de
	 *                   menor prioridade (1) até os de maior prioridade (5).
	 * 
	 * @return int Retorna a posição que o elemento foi cadastrado em Documento.
	 */
	public int criarTexto(String titulo, String valor, int prioridade) {
		if (!(this.documentos.containsKey(titulo))) {
			throw new NoSuchElementException("Documento não existe");
		} else if (titulo.isBlank() || valor.isBlank() || prioridade <= 0) {
			throw new IllegalArgumentException("Dados inválidos");
		} else {
			return this.documentos.get(titulo).criaTexto(valor, prioridade);

		}
	}

	/**
	 * Retorna a posição, do elemento criado TITULO, em Documento.
	 * 
	 * @param titulo     Nome do documento , o qual torna possível sua
	 *                   identificação.
	 * @param valor      Uma string representando os dados desse elemento.
	 * @param prioridade Valor inteiro entre 1-5 (inclusive), indicando elementos de
	 *                   menor prioridade (1) até os de maior prioridade (5).
	 * @param nivel      Um int de 1-5.
	 * @param linkavel   Boolean que determina Upper case nos valores assumidos.
	 * @return int Retorna a posição que o elemento foi cadastrado em Documento.
	 */

	public int criarTitulo(String titulo, String valor, int prioridade, int nivel, boolean linkavel) {
		if (!(this.documentos.containsKey(titulo))) {
			throw new NoSuchElementException("Não existe documento");
		} else if (titulo.isBlank() || valor.isBlank() || prioridade <= 0 || nivel <= 0) {
			throw new IllegalArgumentException("Dados inválidos");
		} else {
			return this.documentos.get(titulo).criaTitulo(valor, prioridade, nivel, linkavel);
		}
	}

	/**
	 * Retorna a posição, do elemento criado LISTA, em Documento.
	 * 
	 * @param titulo     Nome do documento , o qual torna possível sua
	 *                   identificação.
	 * @param valor      Uma string representando os dados desse elemento.
	 * @param prioridade Valor inteiro entre 1-5 (inclusive), indicando elementos de
	 *                   menor prioridade (1) até os de maior prioridade (5).
	 * @param separador  String do caractere que separa os valores desse elemento.
	 * @param charLista  String que fará parte da Representação do elemento criado .
	 * @return int Retorna a posição que o elemento foi cadastrado em Documento.
	 */

	public int criarLista(String titulo, String valor, int prioridade, String separador, String charLista) {
		if (!(this.documentos.containsKey(titulo))) {
			throw new NoSuchElementException("Não existe documento");
		}
		return this.documentos.get(titulo).criaLista(valor, prioridade, separador, charLista);
	}

	/**
	 * Retorna a posição, do elemento criado TERMOS, em Documento.
	 * 
	 * @param titulo     Nome do documento , o qual torna possível sua
	 *                   identificação.
	 * @param valor      Uma string representando os dados desse elemento.
	 * @param prioridade Valor inteiro entre 1-5 (inclusive), indicando elementos de
	 *                   menor prioridade (1) até os de maior prioridade (5).
	 * @param separador  String do caractere que separa os valores desse elemento.
	 * @param ordem      Responsável pela ordenação dos valores na Representação do
	 *                   elemento.
	 * @return int Retorna a posição que o elemento foi cadastrado em Documento.
	 */

	public int criarTermos(String titulo, String valor, int prioridade, String separador, String ordem) {
		if (!(this.documentos.containsKey(titulo))) {
			throw new NoSuchElementException("Não existe documento");
		}
		return this.documentos.get(titulo).criaLista(valor, prioridade, separador, ordem);
	}

	/**
	 * Retorna a Representação Completa de um elemento em determinada posição.
	 * 
	 * @param titulo          Nome do documento , o qual torna possível sua
	 *                        identificação.
	 * @param elementoposicao Posição do elemento que deseja-se pegar a
	 *                        Representação Completa.
	 * @return String Retorna a Representação em String do elemento na posição dita.
	 */

	public String pegarRepresentacaoCompleta(String titulo, int elementoposicao) {
		if (!(this.documentos.containsKey(titulo))) {
			throw new NoSuchElementException("Documento não existe");
		}
		return this.documentos.get(titulo).pegarRepresentacaoCompleta(elementoposicao);
	}

	/**
	 * Retorna a Representação Resumida de um elemento em determinada posição.
	 * 
	 * @param titulo          Nome do documento , o qual torna possível sua
	 *                        identificação.
	 * @param elementoposicao Posição do elemento que deseja-se pegar a
	 *                        Representação Resumida.
	 * @return String Retorna a Representação em String do elemento na posição dita.
	 */

	public String pegarRepresentacaoResumida(String titulo, int elementoposicao) {
		if (!(this.documentos.containsKey(titulo))) {
			throw new NoSuchElementException("Documento não existe");
		}
		return this.documentos.get(titulo).pegarRepresentacaoResumida(elementoposicao);
	}

	/**
	 * Retorna um boolean que representa se o elemento foi apagado com sucesso.
	 * 
	 * @param titulo          Nome do documento , o qual torna possível sua
	 *                        identificação.
	 * @param elementoposicao Posição do elemento que deseja-se apagar.
	 * @return Boolean Retorna se houve o apagamento do elemento no Documento.
	 */

	public boolean apagarElemento(String titulo, int elementoposicao) {
		if (!(this.documentos.containsKey(titulo))) {
			throw new NoSuchElementException("Não existe documento");
		}
		return this.documentos.get(titulo).apagarelementoDocumento(elementoposicao);
	}

	/**
	 * Move um elemento de determinada posição para uma posição vizinha acima.
	 * 
	 * @param titulo          Nome do documento , o qual torna possível sua
	 *                        identificação.
	 * @param elementoposicao Posição do elemento que deseja-se mover.
	 */

	public void moverParaCima(String titulo, int elementoposicao) {
		if (!(this.documentos.containsKey(titulo))) {
			throw new NoSuchElementException("Não existe documento");
		}
		this.documentos.get(titulo).movereParaCima(elementoposicao);
	}

	/**
	 * Move um elemento de determinada posição para uma posição vizinha abaixo.
	 * 
	 * @param titulo          Nome do documento , o qual torna possível sua
	 *                        identificação.
	 * @param elementoposicao Posição do elemento que deseja-se mover.
	 */

	public void moverParaBaixo(String titulo, int elementoposicao) {
		if (!(this.documentos.containsKey(titulo))) {
			throw new NoSuchElementException("Não existe documento");
		}
		this.documentos.get(titulo).moverParaBaixo(elementoposicao);
	}

	/**
	 * Cria um atalho em um Documento, que referencia outro Documento, que o
	 * caracteriza como elemento.
	 * 
	 * @param titulo                Nome do documento , o qual torna possível sua
	 *                              identificação.
	 * @param tituloDocReferenciado Nome do documento a ser referenciado .
	 * @return int Retorna a posição que o elemento foi cadastrado em Documento.
	 */

	public int criarAtalho(String titulo, String tituloDocReferenciado) {
		if (this.documentos.containsKey(titulo) && this.documentos.containsKey(tituloDocReferenciado)) {
			return this.documentos.get(titulo).criarAtalho(titulo,
					this.documentos.get(tituloDocReferenciado).calculaMedia(),
					this.documentos.get(tituloDocReferenciado).getTitulo(),
					this.documentos.get(tituloDocReferenciado).pegarRepresentacaoCompletaAtalho(),
					this.documentos.get(tituloDocReferenciado).pegarRepresentacaoResumidaAtalho());

		} else {
			throw new IllegalStateException("Documento não existe ou não pode ser referenciado");
		}
	}

	/**
	 * Cria uma visão Completa do Documento.
	 * 
	 * @param titulo Nome do documento , o qual torna possível sua identificação.
	 * @return int Retorna o idVisao que foi criado .
	 * 
	 */

	public int criarVisaoCompleta(String titulo) {
		if (this.documentos.containsKey(titulo)) {
			this.visoes.add(this.documentos.get(titulo).criarVisaoCompleta());
			return this.visaoid++;
		}
		throw new NoSuchElementException("Documento não existe");

	}

	/**
	 * Cria uma visão Resumida do Documento.
	 * 
	 * @param titulo Nome do documento , o qual torna possível sua identificação.
	 * @return int Retorna o idVisao que foi criado.
	 */

	public int criarVisaoResumida(String titulo) {
		if (this.documentos.containsKey(titulo)) {
			this.visoes.add(this.documentos.get(titulo).criarVisaoResumida());
			return this.visaoid++;
		}
		throw new NoSuchElementException("Documento não existe");
	}

	/**
	 * Cria uma visão Prioritaria do Documento.
	 * 
	 * @param titulo     Nome do documento , o qual torna possível sua
	 *                   identificação.
	 * @param prioridade Prioridade que deve ser considerada para geração da
	 *                   Representação.
	 * @return int Retorna o idVisao que foi criado.
	 */

	public int criarVisaoPrioritaria(String titulo, int prioridade) {
		if (this.documentos.containsKey(titulo) && prioridade > 0) {
			this.visoes.add(this.documentos.get(titulo).criarVisaoPrioritaria(prioridade));
			return this.visaoid++;
		}
		throw new NoSuchElementException("Documento não existe ou não há elementos com tal prioridade");
	}

	/**
	 * Cria uma visão Titulo do Documento.
	 * 
	 * @param titulo Nome do documento , o qual torna possível sua identificação.
	 * @return int Retorna o idVisao que foi criado.
	 */

	public int criarVisaoTitulo(String titulo) {
		if (this.documentos.containsKey(titulo)) {
			this.visoes.add(this.documentos.get(titulo).criarVisaoTitulo());
			return this.visaoid++;
		}
		throw new NoSuchElementException("Documento não existe ou não há elementos do tipo Titulo");

	}

	/**
	 * Retorna um Array de String da Visão selecionada.
	 * 
	 * @param visaoId int Representação do idVisão que deve ser exibido.
	 * @return Array de String do idVisao selecionado.
	 */

	public String[] exibirVisao(int visaoId) {
		if (this.visoes.isEmpty()) {
			throw new NoSuchElementException("Visão não existe");
		} else if (this.visoes.get(visaoId) != null) {
			return this.visoes.get(visaoId);
		} else {
			throw new NoSuchElementException("Visão não existe");
		}
	}

}