package documin;
import java.util.Arrays;
//import java.util.Arrays;
//import java.util.ArrayList;
import java.util.HashMap;
import java.util.NoSuchElementException;

public class DocumentoController {

	private HashMap<String, Documento> documentos; // string - titulo
	private Object Atalho;
	
	public DocumentoController() {
		this.documentos = new HashMap<String,Documento>();
	}

	public boolean criarDocumento(String titulo, int tamanho) {
		Documento documento = new Documento(titulo, tamanho);
		if ((this.documentos.containsKey(titulo) || this.documentos.getClass()==null)) {
			return false;
			}
		this.documentos.put(titulo, documento);
		return true;
	}

	public boolean criarDocumento(String titulo) {
		Documento documento = new Documento(titulo);
		if ((this.documentos.containsKey(titulo) || this.documentos.getClass()==null)) {
			return false;
		}
		this.documentos.put(titulo, documento);
		return true;
	}

	public void removerDocumento(String titulo) {
		if (!(this.documentos.containsKey(titulo))) {
			throw new NoSuchElementException();
		} else {
			this.documentos.remove(titulo);
		}
	}

	public int contaelementos(String titulo) {
		if (!(this.documentos.containsKey(titulo))) {
			throw new NoSuchElementException();
		}
		return this.documentos.get(titulo).getTamanho();
	}

	public String[] exibirDocumento(String titulo) {
		if (!this.documentos.containsKey(titulo)) {
			throw new NoSuchElementException();
		}
		return (this.documentos.get(titulo).representacaoDocumento());
	}
	
	public int criarTexto(String titulo, String valor, int prioridade) {
		if (!(this.documentos.containsKey(titulo))) {
			return this.documentos.get(titulo).criaTexto(valor, prioridade);
		}
		else if (titulo.isEmpty() || valor.isEmpty() || prioridade <= 0){
			throw new IllegalArgumentException();  }
		else {
			  return this.documentos.get(titulo).criaTexto( valor, prioridade);
			
		}
	}
	
	public int criarTitulo(String titulo, String valor, int prioridade, int nivel, boolean linkavel){
		if (!(this.documentos.containsKey(titulo))) {
			return this.documentos.get(titulo).criaTitulo(valor, prioridade, nivel, linkavel);}
		else if (titulo.isEmpty() || valor.isEmpty() || prioridade <= 0 || nivel <= 0 ) {
			throw new IllegalArgumentException();
		}
		else {
			return this.documentos.get(titulo).criaTitulo(valor,prioridade,nivel,linkavel);
		}
	}

	public int criarLista(String titulo, String valor, int prioridade, String separador, String charLista) {
		if (!(this.documentos.containsKey(titulo))) {
			return this.documentos.get(titulo).criaLista(valor, prioridade, separador, charLista);
		}
		return this.documentos.get(titulo).criaLista(valor, prioridade, separador, charLista);
	}
	
	public int criarTermos(String titulo,String valorTermos, int prioridade, String separador, String ordem) {
		if (!(this.documentos.containsKey(titulo))) {
			return this.documentos.get(titulo).criaTermos(valorTermos,prioridade,separador,ordem);
		}
		return this.documentos.get(titulo).criaLista(valorTermos, prioridade, separador, ordem);
	}
	
	public String pegarRepresentacaoCompleta(String titulo,int elementoposicao) {
		//ver execocoes
		return this.documentos.get(titulo).pegarRepresentacaoCompleta(elementoposicao);
	}
	public String pegarRepresentacaoResumida(String titulo, int elementoposicao) {
		return this.documentos.get(titulo).pegarRepresentacaoResumida(elementoposicao);
	}
	public boolean apagarElemento(String titulo, int elementoposicao) {
		return this.documentos.get(titulo).apagarelementoDocumento(elementoposicao);
	}
	public void moverParaCima(String titulo, int elementoposicao) {
		this.documentos.get(titulo).movereParaCima(elementoposicao);
	}
	public void moverParaBaixo(String titulo, int elementoposicao) {
		this.documentos.get(titulo).moverParaBaixo(elementoposicao);
	}

	public int criarAtalho(String titulo, String tituloDocReferenciado) {
		if (this.documentos.containsKey(titulo) && this.documentos.containsKey(tituloDocReferenciado)) {
			return this.documentos.get(titulo).criarAtalho(tituloDocReferenciado, this.documentos.get(tituloDocReferenciado).calculaMedia(),
					this.documentos.get(tituloDocReferenciado).getTitulo(),
					this.documentos.get(tituloDocReferenciado).pegarRepresentacaoCompletaAtalho(), 
					this.documentos.get(tituloDocReferenciado).pegarRepresentacaoResumidaAtalho());
			
		}
		else {
			throw new IllegalStateException();
		}
	}

	
	
	
	
	

}