package documin;

import java.util.Arrays;
import java.util.HashMap;

/**
 * Representação de Termos , considerado como Elemento.
 * 
 * @author Jamilly Venâncio
 *
 */
public class Termos implements Elemento {

	/**
	 * @param valor        Uma string representando os dados desse elemento.
	 * @param prioridade   Valor inteiro entre 1-5 (inclusive), indicando elementos
	 *                     de menor prioridade (1) até os de maior prioridade (5).
	 * @param separador    String que define os seperadores de valor.
	 * @param propriedades HashMap das propriedades do elemento.
	 * @param ordem        Ordenação dos termos.
	 * 
	 */

	private String valor;
	private int prioridade;
	private String separador;
	private HashMap<String, String> propriedades;
	private String ordem;

	/**
	 * Constrói os Termos
	 * 
	 * @param valor      Uma string representando os dados desse elemento.
	 * @param prioridade Valor inteiro entre 1-5 (inclusive), indicando elementos de
	 *                   menor prioridade (1) até os de maior prioridade (5).
	 * @param separador  String que define os seperadores de valor.
	 * @param ordem      Ordenação dos termos.
	 */

	public Termos(String valor, int prioridade, String separador, String ordem) {
		if (valor.isBlank() || prioridade <= 0 || separador.isBlank() || ordem.isBlank() || prioridade > 5) {
			throw new IllegalArgumentException("Dados Inválidos");
		}
		this.valor = valor;
		this.prioridade = prioridade;
		this.separador = separador;
		this.ordem = ordem;
		this.propriedades = new HashMap<>();
		this.propriedades.put("Valor", valor);
		this.propriedades.put("Prioridade", "" + prioridade);
		this.propriedades.put("Separador", separador);
		this.propriedades.put("ordem", ordem);

	}

	/**
	 * 
	 * @return
	 * 
	 *         public int contador() { int cont =
	 *         this.valor.split(separador).length; return cont; }
	 */

	/**
	 * Gera a Representação Completa de Termos
	 * 
	 * @return String Representação Completa de Termos
	 * 
	 */

	public String RepresentacaoCompleta() {
		String[] a = this.valor.split(separador);
		int tamanho = a.length;
		String repre = "Total termos: " + tamanho + "\n";
		if (this.ordem.toUpperCase() == "ALFABÉTICA") {
			Arrays.sort(a);
		} else {
			Arrays.sort(a);
		}
		repre += "-";
		for (int i = 0; i < a.length; i++) {
			if (i == a.length - 1) {
				repre += a[i] ;
			} else {
				repre += a[i] + ",";
			}
		}
		return repre;
	}

	/**
	 * Gera a Representação Resumida de Termos
	 * 
	 * @return String Representação Resumida de Termos
	 * 
	 */
	public String RepresentacaoResumida() {
		String[] a = this.valor.split(separador);
		String repre = "";
		if (this.ordem.toUpperCase() == "ALFABÉTICA") {
			Arrays.sort(a);
		} else {
			Arrays.sort(a);
		}
		for (int i = 0; i < a.length; i++) {
			if (i== a.length - 1) {
				repre+= a[i];
			} else {
			repre += a[i] + this.separador;
		}}
		return repre;
	}

	
	public double getPrioridade() {
		return this.prioridade;
	}
}
