package documin;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.HashMap;

public class Termos implements Elemento {
	
	private String valor;
	private int prioridade;
	private String separador;
	private HashMap<String,String> propriedades;
	private String ordem;
	
	public Termos(String valor,int prioridade,String separador,  String ordem) {
		if (valor.isEmpty() || prioridade <= 0 || separador.isEmpty() || ordem.isEmpty()) {
			throw new IllegalArgumentException();
		}
		this.valor = valor;
		this.prioridade = prioridade;
		this.separador = separador;
		this.ordem = ordem;
		this.propriedades = new HashMap <>();
		this.propriedades.put("Propriedades", "Separador (string) + Ordem ('NENHUM', 'ALFABÉTICA', 'TAMANHO')");
		
	}
	
	public int contador() {
		int cont = this.valor.split(separador).length;
		return cont;
	}
	@Override
	public String RepresentacaoCompleta() {
		String[] a = this.valor.split(separador);
		String repre = "Total termos: " + a.length + "\n";
		if(this.ordem.toUpperCase() == "ALFABÉTICA") {
			Arrays.sort(a);
		}
		else {
			Arrays.sort(a);
		}
		for (int i = 0; i < a.length; i++) {
			if(i == a.length - 1) {
				repre += a[i];
			}
			else {
			repre += a[i] + this.separador ;
		}
		}
		return repre;
	}
	
	@Override
	public String RepresentacaoResumida() {
		String[] a = this.valor.split(separador);
		String repre = "";
		if(this.ordem.toUpperCase() == "ALFABÉTICA") {
			Arrays.sort(a);
		}
		else {
			Arrays.sort(a);
		}
		for (int i = 0; i < a.length; i++) {
			repre += a[i] + this.separador;
		}
		return repre;
	}


	@Override
	public int getPrioridade() {
		return this.prioridade;
	}
}
