package documin;

import java.util.HashMap;

/**
 * Representação de Lista
 * 
 * @author Jamilly Venâncio
 *
 */

public class Lista implements Elemento {
	/**
	 * @param valorLista   Uma string representando os dados desse elemento.
	 * @param prioridade   Valor inteiro entre 1-5 (inclusive), indicando elementos
	 *                     de menor prioridade (1) até os de maior prioridade (5).
	 * @param propriedades HashMap das propriedades do elemento.
	 * @param separador    String que define os seperadores de valor.
	 * @param charLista    String Caractere da Lista a ser exibida.
	 * 
	 */
	private String valorLista;
	private int prioridade;
	private HashMap<String, String> propriedades;
	private String separador;
	private String charLista;

	/**
	 * Constrói uma Lista
	 * 
	 * @param valorLista Uma string representando os dados desse elemento.
	 * @param prioridade Valor inteiro entre 1-5 (inclusive), indicando elementos de
	 *                   menor prioridade (1) até os de maior prioridade (5).
	 * @param separador  String que define os seperadores de valor.
	 * @param charLista  String Caractere da Lista a ser exibida.
	 */

	public Lista(String valorLista, int prioridade, String separador, String charLista) {
		if (valorLista.isBlank() || prioridade <= 0 || separador.isBlank() || charLista.isBlank() || prioridade > 5) {
			throw new IllegalArgumentException("Dados inválidos");
		}
		this.valorLista = valorLista;
		this.prioridade = prioridade;
		this.separador = separador;
		this.charLista = charLista;
		this.propriedades = new HashMap<>();
		this.propriedades.put("Valor", valorLista);
		this.propriedades.put("prioridade", "" + prioridade);
		this.propriedades.put("separador", separador);
		this.propriedades.put("charlista", charLista);
	}

	/**
	 * Gera a Representação Completa de uma Lista
	 * 
	 * @return String Representação completa de Lista
	 */

	public String RepresentacaoCompleta() {
		String representacaocompleta = this.charLista + " ";
		representacaocompleta += this.valorLista.replace(separador, "\n-");
		return representacaocompleta;
	}

	/**
	 * Gera a Representação Resumida de uma Lista
	 * 
	 * @return String Representação resumida de Lista
	 * 
	 */
	public String RepresentacaoResumida() {
		String representacaoresumida = "";
		String representacao = this.valorLista;// .replace(" ", "");
		representacaoresumida += representacao.replace(separador, ",");
		return representacaoresumida;
	}

	/**
	 * 
	 * 
	 * @Override public String toString() { return RepresentacaoResumida(); }
	 */

	public double getPrioridade() {
		return this.prioridade;
	}
}
