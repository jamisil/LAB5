package documin;

/**
 * Representação de Facede , qual é responsável pela administração do controle
 * do sistema Documin.
 * 
 * @author Jamilly Venâncio
 * 
 */

public class Facade {
	/**
	 * @param documentoController Controller que gerencia os Documentos.
	 */

	private DocumentoController documentoController;

	/**
	 * Constrói um Facade
	 * 
	 */

	public Facade() {
		this.documentoController = new DocumentoController();
	}

	/**
	 * Retorna se o Documento foi criado ou não .
	 * 
	 * @param titulo Nome do documento , o qual torna possível sua identificação.
	 * 
	 * @return boolean Representa se o Documento foi criado ou não.
	 */

	public boolean criarDocumento(String titulo) {
		return this.documentoController.criarDocumento(titulo);
	}

	/**
	 * Retorna se o Documento foi criado ou não.
	 * 
	 * @param titulo  Nome do documento , o qual torna possível sua identificação.
	 * @param tamanho Representa o tamanho dos elementos que podem ser aderidos ao
	 *                Documento.
	 * @return boolean Representa se o Documento foi criado ou não.
	 */

	public boolean criarDocumento(String titulo, int tamanho) {
		return this.documentoController.criarDocumento(titulo, tamanho);
	}

	/**
	 * Remove um Documento pela sua identificação(pelo título).
	 * 
	 * @param titulo Nome do documento , o qual torna possível sua identificação.
	 */

	public void removerDocumento(String titulo) {
		this.documentoController.removerDocumento(titulo);
	}

	/**
	 * Retorna a quantidade de elementos inseridos no Documento.
	 * 
	 * @param titulo Nome do documento , o qual torna possível sua identificação.
	 * @return int Representa a quantidade de elementos no Documento.
	 */
	public int contarElementos(String titulo) {
		return this.documentoController.contaelementos(titulo);

	}

	/**
	 * Retorna um array de String, com uma representação de cada elemento inserido
	 * no Documento.
	 * 
	 * @param titulo Nome do documento , o qual torna possível sua identificação.
	 * @return Array de String de cada elemento presente em Documento.
	 */
	public String[] exibirDocumento(String titulo) {
		return this.documentoController.exibirDocumento(titulo);// Arrays.toString
	}

	/**
	 * Retorna a posição ,do elemento criado TEXTO, em Documento.
	 * 
	 * @param titulo     Nome do documento , o qual torna possível sua
	 *                   identificação.
	 * @param valor      Uma string representando os dados desse elemento.
	 * @param prioridade Valor inteiro entre 1-5 (inclusive), indicando elementos de
	 *                   menor prioridade (1) até os de maior prioridade (5).
	 * 
	 * @return int Retorna a posição que o elemento foi cadastrado em Documento.
	 */
	public int criarTexto(String titulo, String valor, int prioridade) {
		return this.documentoController.criarTexto(titulo, valor, prioridade);
	}

	/**
	 * Retorna a posição, do elemento criado TITULO, em Documento.
	 * 
	 * @param titulo     Nome do documento , o qual torna possível sua
	 *                   identificação.
	 * @param valor      Uma string representando os dados desse elemento.
	 * @param prioridade Valor inteiro entre 1-5 (inclusive), indicando elementos de
	 *                   menor prioridade (1) até os de maior prioridade (5).
	 * @param nivel      Um int de 1-5.
	 * @param linkavel   Boolean que determina Upper case nos valores assumidos.
	 * @return int Retorna a posição que o elemento foi cadastrado em Documento.
	 */
	public int criarTitulo(String titulo, String valor, int prioridade, int nivel, boolean linkavel) {
		return this.documentoController.criarTitulo(titulo, valor, prioridade, nivel, linkavel);
	}

	/**
	 * Retorna a posição, do elemento criado LISTA, em Documento.
	 * 
	 * @param titulo     Nome do documento , o qual torna possível sua
	 *                   identificação.
	 * @param valor      Uma string representando os dados desse elemento.
	 * @param prioridade Valor inteiro entre 1-5 (inclusive), indicando elementos de
	 *                   menor prioridade (1) até os de maior prioridade (5).
	 * @param separador  String do caractere que separa os valores desse elemento.
	 * @param charLista  String que fará parte da Representação do elemento criado .
	 * @return int Retorna a posição que o elemento foi cadastrado em Documento.
	 */

	public int criarLista(String titulo, String valor, int prioridade, String separador, String charLista) {
		return this.documentoController.criarLista(titulo, valor, prioridade, separador, charLista);
	}

	/**
	 * Retorna a posição, do elemento criado TERMOS, em Documento.
	 * 
	 * @param titulo     Nome do documento , o qual torna possível sua
	 *                   identificação.
	 * @param valor      Uma string representando os dados desse elemento.
	 * @param prioridade Valor inteiro entre 1-5 (inclusive), indicando elementos de
	 *                   menor prioridade (1) até os de maior prioridade (5).
	 * @param separador  String do caractere que separa os valores desse elemento.
	 * @param ordem      Responsável pela ordenação dos valores na Representação do
	 *                   elemento.
	 * @return int Retorna a posição que o elemento foi cadastrado em Documento.
	 */

	public int criarTermos(String titulo, String valor, int prioridade, String separador, String ordem) {
		return this.documentoController.criarTermos(titulo, valor, prioridade, separador, ordem);
	}

	/**
	 * Retorna a Representação Completa de um elemento em determinada posição.
	 * 
	 * @param titulo          Nome do documento , o qual torna possível sua
	 *                        identificação.
	 * @param elementoposicao Posição do elemento que deseja-se pegar a
	 *                        Representação Completa.
	 * @return String Retorna a Representação em String do elemento na posição dita.
	 */

	public String pegarRepresentacaoCompleta(String titulo, int elementoposicao) {
		return this.documentoController.pegarRepresentacaoCompleta(titulo, elementoposicao);
	}

	/**
	 * Retorna a Representação Resumida de um elemento em determinada posição.
	 * 
	 * @param titulo          Nome do documento , o qual torna possível sua
	 *                        identificação.
	 * @param elementoposicao Posição do elemento que deseja-se pegar a
	 *                        Representação Resumida.
	 * @return String Retorna a Representação em String do elemento na posição dita.
	 */
	public String pegarRepresentacaoResumida(String titulo, int elementoposicao) {
		return this.documentoController.pegarRepresentacaoResumida(titulo, elementoposicao);
	}

	/**
	 * Retorna um boolean que representa se o elemento foi apagado com sucesso.
	 * 
	 * @param titulo          Nome do documento , o qual torna possível sua
	 *                        identificação.
	 * @param elementoposicao Posição do elemento que deseja-se apagar.
	 * @return Boolean Retorna se houve o apagamento do elemento no Documento.
	 */

	public boolean apagarElemento(String titulo, int elementoposicao) {
		return this.documentoController.apagarElemento(titulo, elementoposicao);
	}

	/**
	 * Move um elemento de determinada posição para uma posição vizinha acima.
	 * 
	 * @param titulo          Nome do documento , o qual torna possível sua
	 *                        identificação.
	 * @param elementoposicao Posição do elemento que deseja-se mover.
	 */
	public void moverParaCima(String titulo, int elementoposicao) {
		this.documentoController.moverParaCima(titulo, elementoposicao);
	}

	/**
	 * Move um elemento de determinada posição para uma posição vizinha abaixo.
	 * 
	 * @param titulo          Nome do documento , o qual torna possível sua
	 *                        identificação.
	 * @param elementoposicao Posição do elemento que deseja-se mover.
	 */

	public void moverParaBaixo(String titulo, int elementoposicao) {
		this.documentoController.moverParaBaixo(titulo, elementoposicao);
	}

	/**
	 * Cria um atalho em um Documento, que referencia outro Documento, que o
	 * caracteriza como elemento.
	 * 
	 * @param titulo                Nome do documento , o qual torna possível sua
	 *                              identificação.
	 * @param tituloDocReferenciado Nome do documento a ser referenciado .
	 * @return int Retorna a posição que o elemento foi cadastrado em Documento.
	 */

	public int criarAtalho(String titulo, String tituloDocReferenciado) {
		return this.documentoController.criarAtalho(titulo, tituloDocReferenciado);
	}

	/**
	 * Cria uma visão Completa do Documento.
	 * 
	 * @param titulo Nome do documento , o qual torna possível sua identificação.
	 * @return int Retorna o idVisao que foi criado .
	 * 
	 */
	public int criarVisaoCompleta(String titulo) {
		return this.documentoController.criarVisaoCompleta(titulo);
	}

	/**
	 * Cria uma visão Resumida do Documento.
	 * 
	 * @param titulo Nome do documento , o qual torna possível sua identificação.
	 * @return int Retorna o idVisao que foi criado.
	 */

	public int criarVisaoResumida(String titulo) {
		return this.documentoController.criarVisaoResumida(titulo);
	}

	/**
	 * Cria uma visão Prioritaria do Documento.
	 * 
	 * @param titulo     Nome do documento , o qual torna possível sua
	 *                   identificação.
	 * @param prioridade Prioridade que deve ser considerada para geração da
	 *                   Representação.
	 * @return int Retorna o idVisao que foi criado.
	 */

	public int criarVisaoPrioritaria(String titulo, int prioridade) {
		return this.documentoController.criarVisaoPrioritaria(titulo, prioridade);
	}

	/**
	 * Cria uma visão Titulo do Documento.
	 * 
	 * @param titulo Nome do documento , o qual torna possível sua identificação.
	 * @return int Retorna o idVisao que foi criado.
	 */

	public int criarVisaoTitulo(String titulo) {
		return this.documentoController.criarVisaoTitulo(titulo);
	}

	/**
	 * Retorna um Array de String da Visão selecionada.
	 * 
	 * @param visaoId int Representação do idVisão que deve ser exibido.
	 * @return Array de String do idVisao selecionado.
	 */

	public String[] exibirVisao(int visaoId) {
		return this.documentoController.exibirVisao(visaoId);
	}

}