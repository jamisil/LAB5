package documin;

import java.util.HashMap;

public class Titulo implements Elemento {
	private String valor;
    private HashMap<String,String> propriedades;
	private int prioridade = 1;
	private int nivel;
	private boolean linkavel;
	
	public Titulo(String valor, int prioridade, int nivel, boolean linkavel) {
		if (valor == null || valor.isEmpty() || prioridade <= 0 || nivel <= 0) {
			throw new IllegalArgumentException();	
		}
		this.valor = valor;
		this.prioridade = prioridade; // fazer a herança
		this.nivel = nivel;
		this.linkavel = linkavel;
		this.propriedades = this.propriedades = new HashMap <>();
		this.propriedades.put("Propriedades", "Nível (inteiro 1-5, inclusive)\n"+ "Linkável (booleano)\n"+ "\n");
	}
	@Override
	public String RepresentacaoCompleta() {
		String link = this.nivel + this.valor;
		if (this.linkavel == true) {
			 link = this.nivel + "-" + this.valor.toUpperCase().replace(" ", "");
			 return this.nivel + "." + this.valor + "--\n" + link;
		}
		return this.nivel  + this.valor + "--" ; 
	}
	@Override
	public String RepresentacaoResumida() {
		return this.nivel + "." + this.valor;
	}
	
	public int getPrioridade() {
		return this.prioridade;
	}
}
