package documin;

import java.util.HashMap;

/**
 * Representação do Título, caracterizado como Elemento.
 * 
 * @author Jamilly Venâncio
 *
 */
public class Titulo implements Elemento {
	/**
	 * @param valor        Uma string representando os dados desse elemento.
	 * @param prioridade   Valor inteiro entre 1-5 (inclusive), indicando elementos
	 *                     de menor prioridade (1) até os de maior prioridade (5).
	 * @param nivel        Um int de 1-5.
	 * @param linkavel     Boolean que determina Upper case nos valores assumidos.
	 * @param propriedades HashMap das propriedades do elemento.
	 * 
	 */
	private String valor;
	private int prioridade;
	private int nivel;
	private boolean linkavel;
	private HashMap<String, String> propriedades;

	/**
	 * Constrói um Título
	 * 
	 * @param valor      Uma string representando os dados desse elemento.
	 * @param prioridade Valor inteiro entre 1-5 (inclusive), indicando elementos de
	 *                   menor prioridade (1) até os de maior prioridade (5).
	 * @param nivel      Um int de 1-5.
	 * @param linkavel   Boolean que determina Upper case nos valores assumidos.
	 */

	public Titulo(String valor, int prioridade, int nivel, boolean linkavel) {
		if (valor == null || valor.isEmpty() || prioridade <= 0 || nivel <= 0 || prioridade > 5) {
			throw new IllegalArgumentException("Dados Inválidos");
		}
		this.valor = valor;
		this.prioridade = prioridade;
		this.nivel = nivel;
		this.linkavel = linkavel;
		this.propriedades = new HashMap<String,String>();
		this.propriedades.put(valor, valor);
		this.propriedades.put("prioridade", "" + prioridade);
		this.propriedades.put("nivel", "" + nivel);
		this.propriedades.put("boolean", "" + linkavel);
	}

	/**
	 * Gera a RepresentacaoCompleta de Titulo
	 * 
	 * @return String Representacao em String do Titulo.
	 * 
	 */
	public String RepresentacaoCompleta() {
		String link = this.nivel + this.valor;
		if (this.linkavel == true) {
			link = this.nivel + "-" + this.valor.toUpperCase().replace(" ", "");
			return this.nivel + "." + this.valor + "--\n" + link;
		}
		return this.nivel + this.valor + "--";
	}

	/**
	 * Gera a RepresentacaoResumida de Titulo
	 * 
	 * @return String Representacao em String do Titulo
	 */

	public String RepresentacaoResumida() {
		return this.nivel + "." + this.valor;
	}

	public double getPrioridade() {
		return this.prioridade;
	}
}
