package documin;

import java.util.HashMap;

/**
 * Representação de Texto , que é caracterizado como elemento.
 * 
 * @author Jamilly Venâncio
 *
 */

public class Texto implements Elemento {
	/**
	 * @param valor        Uma string representando os dados desse elemento.
	 * @param propriedades HashMap das propriedades do elemento.
	 * @param prioridade   Valor inteiro entre 1-5 (inclusive), indicando elementos
	 *                     de menor prioridade (1) até os de maior prioridade (5).
	 */

	private String valor;
	private HashMap<String, String> propriedades;
	private int prioridade;

	/**
	 * 
	 * Constrói um Texto
	 * 
	 * @param valor      Uma string representando os dados desse elemento.
	 * @param prioridade Valor inteiro entre 1-5 (inclusive), indicando elementos de
	 *                   menor prioridade (1) até os de maior prioridade (5).
	 */

	public Texto(String valor, int prioridade) {
		if (valor == null || valor.isBlank()) {
			throw new IllegalArgumentException("Dados Inválidos");
		} else if (prioridade <= 0 || prioridade > 5) {
			throw new IllegalArgumentException("Dados Inválidos");
		}
		this.valor = valor;
		this.prioridade = prioridade;
		this.propriedades = new HashMap<>();
		this.propriedades.put("Sem Propriedades", "------");
	}

//	public String toString() {
	// return RepresentacaoResumida();

//	}
	/**
	 * Gera a Representação Completa de texto
	 * 
	 * @return String Representação Completa de texto
	 * 
	 */

	public String RepresentacaoCompleta() {
		return this.valor;
	}

	/**
	 * Gera a Representação Resumida de texto
	 * 
	 * @return String Representação Resumida de texto.
	 * 
	 */

	public String RepresentacaoResumida() {
		return this.valor;
	}

	public double getPrioridade() {
		return this.prioridade;
	}
}
