package documin;

import java.util.HashMap;

public class Texto implements Elemento {
	
	private String valor;
	private HashMap<String, String> propriedades ;
	private int prioridade;
	
	public Texto(String valor, int prioridade) {
		if (valor == null || valor.isEmpty()) {
			throw new IllegalArgumentException();
		}
		else if (prioridade <= 0) {
			throw new IllegalArgumentException();
		}
		this.valor = valor;
		this.prioridade = prioridade;
		this.propriedades = new HashMap <>();
		this.propriedades.put("Propriedades", "-- sem propriedades -");
	}
	
	
	@Override
	public String toString() {
		return RepresentacaoResumida();
		
	}

	@Override
	public String RepresentacaoCompleta() {
		return this.valor;
	}

	@Override
	public String RepresentacaoResumida() {
		// TODO Auto-generated method stub
		return this.valor;
	}
	
	public int getPrioridade() {
		return this.prioridade;
	}
}
