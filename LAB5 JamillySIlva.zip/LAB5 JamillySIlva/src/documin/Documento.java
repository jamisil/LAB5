package documin;

import java.util.ArrayList;
import java.util.Collections;
import java.util.NoSuchElementException;
import java.util.Objects;

/**
 * Representação de Documento.
 * 
 * @author Jamilly Venâncio
 *
 */
public class Documento {
	/**
	 * @param titulo    String que representa o titulo (chave) que identifica o
	 *                  Documento.
	 * @param tamanho   int Tamanho máximo de Documento
	 * @param contador  int Conta elementos presentes no Documento
	 * @param elementos ArrayList de elementos presentes em Documento.
	 * 
	 */

	private String titulo;
	private int tamanho;
	private int contador;
	private ArrayList<Elemento> elementos;

	/**
	 * Constrói Documento, sem restrição de tamanho.
	 * 
	 * @param titulo String que representa o titulo (chave) que identifica o
	 *               Documento.
	 */

	public Documento(String titulo) {
		if (titulo == null || titulo.isBlank()) {
			throw new IllegalArgumentException("Dados Inválidos");
		}
		this.titulo = titulo;
		this.elementos = new ArrayList<>();

	}

	/**
	 * Constrói Documento, com restrição de tamanho.
	 * 
	 * @param titulo        String que representa o titulo (chave) que identifica o
	 *                      Documento.
	 * @param tamanhomaximo int Definição da capacidade do Documento.
	 */

	public Documento(String titulo, int tamanhomaximo) {
		if (titulo == null || titulo.isBlank()) {
			throw new IllegalArgumentException("Dados Inválidos");
		} else if (tamanhomaximo <= 0) {
			throw new IllegalArgumentException("Dados Inválidos");
		}
		this.titulo = titulo;
		this.tamanho = tamanhomaximo;
		this.elementos = new ArrayList<>(this.tamanho);
	}

	private boolean limitatamanho() {
		if (this.tamanho == this.contador && this.tamanho != 0 && this.contador != 0) {
			return true;
		}
		return false;

	}

	private boolean TemAtalho() {
		if (this.elementos.isEmpty()) {
			throw new NoSuchElementException("Documento não existe !");
		}
		for (int i = 0; i < this.elementos.size(); i++) {
			if (this.elementos.get(i).getClass() == Atalho.class) {
				return true;
			}
		}
		return false;

	}

	public String getTitulo() {
		return this.titulo;
	}

	@Override
	public int hashCode() {
		return Objects.hash(getTitulo());
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Documento other = (Documento) obj;
		return Objects.equals(getTitulo(), other.getTitulo());
	}

	/**
	 * Retorna um array de String da Representação de todos os elementos do
	 * Documento.
	 * 
	 * @return Array de String Representa todos os elementos presentes no Documento.
	 */
	public String[] representacaoDocumento() {
		String[] representacao = new String[getElementos().size()];
		if (getElementos().isEmpty()) {
			return representacao;
		}
		for (int i = 0; i < this.elementos.size(); i++) {
			String a = this.elementos.get(i).RepresentacaoResumida();
			representacao[i] = a;
		}
		return representacao;
	}

	/**
	 * Retorna a posição ,do elemento criado TEXTO, em Documento.
	 * 
	 * @param titulo     Nome do documento , o qual torna possível sua
	 *                   identificação.
	 * @param valor      Uma string representando os dados desse elemento.
	 * @param prioridade Valor inteiro entre 1-5 (inclusive), indicando elementos de
	 *                   menor prioridade (1) até os de maior prioridade (5).
	 * 
	 * @return int Retorna a posição que o elemento foi cadastrado em Documento.
	 */
	public int criaTexto(String valor, int prioridade) {
		if (valor.isBlank() || prioridade < 0 || prioridade > 5) {
			throw new IllegalArgumentException("Dados Inválidos");
		}
		if (this.tamanho != 0 && limitatamanho()) {
			throw new IllegalArgumentException("Atingiu limite");
		}
		Texto texto = new Texto(valor, prioridade);
		this.contador += 1;
		this.elementos.add(texto);
		return this.elementos.indexOf(texto);
	}

	/**
	 * Retorna a posição, do elemento criado TITULO, em Documento.
	 * 
	 * @param titulo     Nome do documento , o qual torna possível sua
	 *                   identificação.
	 * @param valor      Uma string representando os dados desse elemento.
	 * @param prioridade Valor inteiro entre 1-5 (inclusive), indicando elementos de
	 *                   menor prioridade (1) até os de maior prioridade (5).
	 * @param nivel      Um int de 1-5.
	 * @param linkavel   Boolean que determina "Upper case" nos valores assumidos.
	 * @return int Retorna a posição que o elemento foi cadastrado em Documento.
	 */

	public int criaTitulo(String valor, int prioridade, int nivel, boolean linkavel) {
		Titulo titulo = new Titulo(valor, prioridade, nivel, linkavel);
		if (this.tamanho != 0 && limitatamanho()) {
			throw new IllegalArgumentException("Atingiu limite");
		}
		this.contador += 1;
		this.getElementos().add(titulo);
		return this.getElementos().indexOf(titulo);
	}

	/**
	 * Retorna a posição, do elemento criado LISTA, em Documento.
	 * 
	 * @param titulo     Nome do documento , o qual torna possível sua
	 *                   identificação.
	 * @param valor      Uma string representando os dados desse elemento.
	 * @param prioridade Valor inteiro entre 1-5 (inclusive), indicando elementos de
	 *                   menor prioridade (1) até os de maior prioridade (5).
	 * @param separador  String do caractere que separa os valores desse elemento.
	 * @param charLista  String que fará parte da Representação do elemento criado .
	 * @return int Retorna a posição que o elemento foi cadastrado em Documento.
	 */

	public int criaLista(String valor, int prioridade, String separador, String charLista) {
		Lista lista = new Lista(valor, prioridade, separador, charLista);
		if (this.tamanho != 0 && limitatamanho()) {
			throw new IllegalArgumentException("Atingiu limite");
		}
		this.contador += 1;
		this.getElementos().add(lista);
		return this.getElementos().indexOf(lista);
	}

	/**
	 * Retorna a posição, do elemento criado TERMOS, em Documento.
	 * 
	 * @param titulo     Nome do documento , o qual torna possível sua
	 *                   identificação.
	 * @param valor      Uma string representando os dados desse elemento.
	 * @param prioridade Valor inteiro entre 1-5 (inclusive), indicando elementos de
	 *                   menor prioridade (1) até os de maior prioridade (5).
	 * @param separador  String do caractere que separa os valores desse elemento.
	 * @param ordem      Responsável pela ordenação dos valores na Representação do
	 *                   elemento.
	 * @return int Retorna a posição que o elemento foi cadastrado em Documento.
	 */

	public int criaTermos(String valorTermos, int prioridade, String separador, String ordem) {
		Termos termos = new Termos(valorTermos, prioridade, separador, ordem);
		if (this.tamanho != 0 && limitatamanho()) {
			throw new IllegalArgumentException("Atingiu limite");
		}
		this.contador += 1;
		this.getElementos().add(termos);
		return this.getElementos().indexOf(termos);
	}

	/**
	 * Retorna a Representação Completa de um elemento em determinada posição.
	 * 
	 * @param titulo          Nome do documento , o qual torna possível sua
	 *                        identificação.
	 * @param elementoposicao Posição do elemento que deseja-se pegar a
	 *                        Representação Completa.
	 * @return String Retorna a Representação em String do elemento na posição dita.
	 */

	public String pegarRepresentacaoCompleta(int elementoposicao) {
		if (elementoposicao < this.elementos.size() - 1 || elementoposicao > this.elementos.size() - 1
				|| elementoposicao < 0) {
			throw new IllegalArgumentException("Dado inválido");
		}
		return this.elementos.get(elementoposicao).RepresentacaoCompleta();

	}

	/**
	 * Retorna a Representação Resumida de um elemento em determinada posição.
	 * 
	 * @param titulo          Nome do documento , o qual torna possível sua
	 *                        identificação.
	 * @param elementoposicao Posição do elemento que deseja-se pegar a
	 *                        Representação Resumida.
	 * @return String Retorna a Representação em String do elemento na posição dita.
	 */

	public String pegarRepresentacaoResumida(int elementoposicao) {
		if (elementoposicao < this.elementos.size() - 1 || elementoposicao > this.elementos.size() - 1
				|| elementoposicao < 0) {
			throw new IllegalArgumentException("Dado inválido");
		}
		return this.getElementos().get(elementoposicao).RepresentacaoResumida();
	}

	/**
	 * Move um elemento de determinada posição para uma posição vizinha acima.
	 * 
	 * @param titulo          Nome do documento , o qual torna possível sua
	 *                        identificação.
	 * @param elementoposicao Posição do elemento que deseja-se mover.
	 */

	public void movereParaCima(int elementoposicao) {
		if (elementoposicao != 0 && (this.getElementos().size() - 1 >= elementoposicao
				|| elementoposicao <= this.getElementos().size() - 1)) {
			Collections.swap(this.getElementos(), elementoposicao, elementoposicao + 1);
		}
	}

	/**
	 * Move um elemento de determinada posição para uma posição vizinha abaixo.
	 * 
	 * @param titulo          Nome do documento , o qual torna possível sua
	 *                        identificação.
	 * @param elementoposicao Posição do elemento que deseja-se mover.
	 */

	public void moverParaBaixo(int elementoposicao) {
		if (elementoposicao != 0 && elementoposicao == this.getElementos().size() - 1) {
			Collections.swap(this.getElementos(), elementoposicao, elementoposicao - 1);
		}
	}

	/**
	 * Retorna um boolean que representa se o elemento foi apagado com sucesso.
	 * 
	 * @param titulo          Nome do documento , o qual torna possível sua
	 *                        identificação.
	 * @param elementoposicao Posição do elemento que deseja-se apagar.
	 * @return Boolean Retorna se houve o apagamento do elemento no Documento.
	 */
	public boolean apagarelementoDocumento(int elementoposicao) {
		if (elementoposicao < this.elementos.size() - 1 || elementoposicao > this.elementos.size() - 1
				|| elementoposicao < 0) {
			throw new IllegalArgumentException("Dado inválido");
		} else if (this.getElementos().get(elementoposicao) == null) {
			return false;
		}
		this.getElementos().remove(elementoposicao);
		return true;
	}

	/**
	 * Calcula a média das prioridades dos elementos presentes no Documento.
	 * 
	 * @return double A média das prioridades.
	 */

	public double calculaMedia() {
		double soma = 0;
		for (int i = 0; i < getElementos().size(); i++) {
			soma += this.elementos.get(i).getPrioridade();
		}
		double media = soma / this.elementos.size();
		return media;
	}

	public ArrayList<Elemento> getElementos() {
		return this.elementos;
	}

	public int getTamanho() {
		return this.tamanho;
	}

	/**
	 * Retorna a Representação Completa,com elementos com prioridade acima de 3, de
	 * um Atalho
	 * 
	 * @return String Com a representação Completa de um Atalho
	 */
	public String pegarRepresentacaoCompletaAtalho() {
		String representacao = "";
		for (int i = 0; i < this.elementos.size(); i++) {
			if (this.elementos.get(i).getPrioridade() > 3) {
				representacao += this.elementos.get(i).RepresentacaoCompleta();
			}
		}
		return representacao;
	}

	/**
	 * Retorna a Representação Resumida, com elementos com prioridade acima de 3, de
	 * um Atalho.
	 * 
	 * @return String Com a representação Resumida de um Atalho
	 */

	public String pegarRepresentacaoResumidaAtalho() {
		String representacao = "";
		for (int i = 0; i < this.elementos.size(); i++) {
			if (this.elementos.get(i).getPrioridade() > 3) {
				representacao += this.elementos.get(i).RepresentacaoResumida();
			}
		}
		return representacao;
	}

	/**
	 * Cria um atalho em um Documento, que referencia outro Documento, que o
	 * caracteriza como elemento.
	 * 
	 * @param tituloDoc             Nome do documento , o qual torna possível sua
	 *                              identificação.
	 * @param prioridade            Média das prioridades do Documento Referenciado.
	 * @param valor                 id do documento Referenciado.
	 * @param representacaoCompleta Representação de todos os elementos do documento
	 *                              referenciado.
	 * @param representacaoResumida Representação de todos os elementos do documento
	 *                              referenciado.
	 * @return int Retorna a posição que o elemento foi cadastrado em Documento.
	 */

	public int criarAtalho(String tituloDoc, double prioridade, String valor, String representacaoCompleta,
			String representacaoResumida) {
		Atalho atalho = new Atalho(tituloDoc, prioridade, valor, representacaoCompleta, representacaoResumida);
		if (this.elementos.contains(atalho) && TemAtalho()) {
			return this.elementos.indexOf(atalho);
		}
		if (limitatamanho() && this.tamanho != 0) {
			throw new IllegalArgumentException("Atingiu limite");
		}
		this.contador += 1;
		this.elementos.add(atalho);
		return this.elementos.indexOf(atalho);
	}

	/**
	 * Cria uma visão Completa do Documento.
	 * 
	 * @return Um Array de String com uma Visão Completa.
	 * 
	 */

	public String[] criarVisaoCompleta() {
		String[] visao = new String[this.elementos.size()];
		for (int i = 0; i < this.elementos.size(); i++) {
			visao[i] = this.elementos.get(i).RepresentacaoCompleta();
		}
		return visao;

	}

	/**
	 * Cria uma visão Resumida do Documento.
	 * 
	 * @return Um array de String com uma Visão Resumida.
	 */

	public String[] criarVisaoResumida() {
		String[] visao = new String[this.elementos.size()];
		for (int i = 0; i < this.elementos.size(); i++) {
			visao[i] = this.elementos.get(i).RepresentacaoResumida();
		}
		return visao;
	}

	/**
	 * Cria uma visão Prioritária do Documento.
	 * 
	 * @param prioridade int Define a prioridade que terá na Visão criada.
	 * @return Um array de String com uma visão prioritária.
	 */

	public String[] criarVisaoPrioritaria(int prioridade) {
		String[] visao = new String[this.elementos.size()];
		for (int i = 0; i < this.elementos.size(); i++) {
			if (this.elementos.get(i).getPrioridade() == prioridade) {
				visao[i] = this.elementos.get(i).RepresentacaoCompleta();
			}
		}
		return visao;
	}

	/**
	 * Cria uma visão Título, com elementos apenas do tipo Título.
	 * 
	 * @return Um array de String com uma visão Título.
	 */

	public String[] criarVisaoTitulo() {
		String[] visao = new String[this.elementos.size()];
		for (int i = 0; i < this.elementos.size(); i++) {
			if (this.elementos.get(i).getClass() == Titulo.class) {
				visao[i] = this.elementos.get(i).RepresentacaoResumida();
			}
		}
		return visao;
	}

}
