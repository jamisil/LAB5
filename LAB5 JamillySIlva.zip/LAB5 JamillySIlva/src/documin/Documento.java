package documin;

//import java.sql.Array;
import java.util.ArrayList;
import java.util.Arrays;
//import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
//import java.util.Arrays;
import java.util.Objects;

public class Documento {
	private String titulo;
	private int tamanho;
	private ArrayList<Elemento> elementos;
	private HashMap<Integer,Atalho> atalhos;

	public Documento(String titulo) {
		if (titulo == null || titulo.isEmpty()) {
			throw new IllegalArgumentException("Dados Inválidos");
		}
		this.titulo = titulo;
		this.elementos = new ArrayList<>();

	}

	public Documento(String titulo, int tamanhomaximo) {
		if (titulo == null || titulo.isEmpty()) {
			throw new IllegalArgumentException("Dados Inválidos");
		} else if (tamanhomaximo <= 0) {
			throw new IllegalArgumentException("Dados Inválidos");
		}
		this.titulo = titulo;
		this.tamanho = tamanhomaximo;
		this.elementos = new ArrayList<>(getTamanho());
	}

	public int getQuantidadeAtalho() {
		return this.atalhos.size();
	}

	public String getTitulo() {
		return this.titulo;
	}

	@Override
	public int hashCode() {
		return Objects.hash(getTitulo());
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Documento other = (Documento) obj;
		return Objects.equals(getTitulo(), other.getTitulo());
	}


	public String[] representacaoDocumento() {
		String[] representacao = new String[getElementos().size()];
		if (getElementos().isEmpty()) {
			return representacao;
		}
		for (int i = 0; i < this.elementos.size(); i++) {
			String a = this.elementos.get(i).RepresentacaoResumida();
			representacao[i] = a;
		}
		return representacao;
	}

	public int criaTexto( String valor, int prioridade) {
		if ( valor.isEmpty() || prioridade <= 0) {
			throw new IllegalArgumentException();
		}
		Texto texto = new Texto(valor, prioridade);
		this.elementos.add(texto);
		return this.elementos.indexOf(texto);
	}
	
	public int criaTitulo(String valor, int prioridade, int nivel, boolean linkavel) {
		Titulo titulo = new Titulo(valor, prioridade, nivel, linkavel);
		this.getElementos().add(titulo);
		return this.getElementos().indexOf(titulo);
	}
	
	public int criaLista(String valor, int prioridade, String separador, String charLista) {
		Lista lista = new Lista(valor, prioridade, separador, charLista);
		this.getElementos().add(lista);
		return this.getElementos().indexOf(lista);
	}
	
	public int criaTermos(String valorTermos, int prioridade, String separador, String ordem) {
		Termos termos = new Termos(valorTermos,prioridade,separador,ordem);
		this.getElementos().add(termos);
		return this.getElementos().indexOf(termos);
	}
	public String pegarRepresentacaoCompleta(int elementoposicao) {
		return this.getElementos().get(elementoposicao).RepresentacaoCompleta();
		
	}
	public String pegarRepresentacaoResumida(int elementoposicao) {
		return this.getElementos().get(elementoposicao).RepresentacaoResumida();
	}

	public void movereParaCima(int elementoposicao) {
		if(elementoposicao != 0 && elementoposicao == this.getElementos().size()-1) {
		Collections.swap(this.getElementos(), elementoposicao, elementoposicao + 1);
		}
	}

	public void moverParaBaixo(int elementoposicao) {
		if(elementoposicao != 0 && elementoposicao == this.getElementos().size()-1) {
			Collections.swap(this.getElementos(), elementoposicao, elementoposicao - 1);
		}
	}

	public boolean apagarelementoDocumento(int elementoposicao) {
		if (this.getElementos().get(elementoposicao)== null) {
			return false;		
		}
		this.getElementos().remove(elementoposicao);
		return true;
	}

	public double calculaMedia() {
		double soma = 0;
		for(int i = 0; i < getElementos().size(); i++) {
			soma +=  this.elementos.get(i).getPrioridade();
		}
		double media = soma / this.elementos.size();
		return media;
	}

	public ArrayList<Elemento> getElementos() {
		return this.elementos;
	}

	public int getTamanho() {
		return this.tamanho;
	}

	public String pegarRepresentacaoCompletaAtalho() {
		String representacao = "";
		for(int i = 0 ; i < this.elementos.size(); i++) {
			if(this.elementos.get(i).getPrioridade() > 3 ) {
				representacao += this.elementos.get(i).RepresentacaoCompleta();
			}
		}
		return representacao;
	}
	public String pegarRepresentacaoResumidaAtalho() {
		String representacao = "";
		for(int i = 0 ; i < this.elementos.size(); i++) {
			if(this.elementos.get(i).getPrioridade() > 3) {
				representacao += this.elementos.get(i).RepresentacaoResumida();
			}
		}
		return representacao;
	}
	public int criarAtalho(String tituloDocReferenciado,double prioridade, String valor, String representacaoCompleta, String representacaoResumida) {
		Atalho atalho = new Atalho(tituloDocReferenciado,prioridade,valor,representacaoCompleta,representacaoResumida);
		this.elementos.add(atalho);
		return this.elementos.indexOf(atalho);
	}

	

	

}
