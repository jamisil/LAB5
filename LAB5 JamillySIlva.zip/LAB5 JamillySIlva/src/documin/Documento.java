package documin;

//import java.sql.Array;
import java.util.ArrayList;
//import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
//import java.util.Arrays;
import java.util.Objects;

public class Documento {
	private String titulo;
	private int tamanho;
	private ArrayList<Elemento> elementos;
	private HashMap<Integer,Atalho> atalhos;

	public Documento(String titulo) {
		if (titulo == null || titulo.isEmpty()) {
			throw new IllegalArgumentException("Dados Inválidos");
		}
		this.titulo = titulo;
		this.elementos = new ArrayList<>();

	}

	public Documento(String titulo, int tamanhomaximo) {
		if (titulo == null || titulo.isEmpty()) {
			throw new IllegalArgumentException("Dados Inválidos");
		} else if (tamanhomaximo <= 0) {
			throw new IllegalArgumentException("Dados Inválidos");
		}
		this.titulo = titulo;
		this.tamanho = tamanhomaximo;
		this.elementos = new ArrayList<>(tamanho);
	}

	public int getnumeroelementos() {
		return elementos.size();
	}

	public int getQuantidadeAtalho() {
		return this.atalhos.size();
	}

	public String getTitulo() {
		return this.titulo;
	}

	@Override
	public int hashCode() {
		return Objects.hash(getTitulo());
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Documento other = (Documento) obj;
		return Objects.equals(getTitulo(), other.getTitulo());
	}


	public String[] representacaoDocumento() {
		String[] representacao = new String[elementos.size()];
		if (elementos.isEmpty()) {
			return representacao;
		}
		for (int i = 0; i <= this.tamanho; i++) {
			String a = this.elementos.get(i).RepresentacaoResumida();
			representacao[i] = a;
		}
		return representacao;
	}

//	private ArrayList<Elemento> getelementos() {
	//	return this.elementos;
	//}

	public int criaTexto( String valor, int prioridade) {
		if ( valor.isEmpty() || prioridade <= 0) {
			throw new IllegalArgumentException();
		}
		Texto texto = new Texto(valor, prioridade);
		this.elementos.add(texto);
		return this.elementos.indexOf(texto);
	}
	
	public int criaTitulo(String valor, int prioridade, int nivel, boolean linkavel) {
		Titulo titulo = new Titulo(valor, prioridade, nivel, linkavel);
		this.elementos.add(titulo);
		return this.elementos.indexOf(titulo);
	}
	
	public int criaLista(String valor, int prioridade, String separador, String charLista) {
		Lista lista = new Lista(valor, prioridade, separador, charLista);
		this.elementos.add(lista);
		return this.elementos.indexOf(lista);
	}
	
	public int criaTermos(String valorTermos, int prioridade, String separador, String ordem) {
		Termos termos = new Termos(valorTermos,prioridade,separador,ordem);
		this.elementos.add(termos);
		return this.elementos.indexOf(termos);
	}
	public String pegarRepresentacaoCompleta(int elementoposicao) {
		return this.elementos.get(elementoposicao).RepresentacaoCompleta();
		
	}
	public String pegarRepresentacaoResumida(int elementoposicao) {
		return this.elementos.get(elementoposicao).RepresentacaoResumida();
	}

	public void movereParaCima(int elementoposicao) {
		if(elementoposicao != 0 && elementoposicao == this.getnumeroelementos()-1) {
		Collections.swap(this.elementos, elementoposicao, elementoposicao + 1);
		}
	}

	public void moverParaBaixo(int elementoposicao) {
		if(elementoposicao != 0 && elementoposicao == this.getnumeroelementos()-1) {
			Collections.swap(this.elementos, elementoposicao, elementoposicao - 1);
		}
	}

	public boolean apagarelementoDocumento(int elementoposicao) {
		if (this.elementos.get(elementoposicao)== null) {
			return false;		
		}
		this.elementos.remove(elementoposicao);
		return true;
	}

	public double calculaMedia() {
		int soma = 0;
		for(int i = 0; i <= elementos.size(); i++) {
			soma +=  this.elementos.get(i).getPrioridade();
		}
		double media = soma / this.elementos.size();
		return media;
	}

	

	

}
