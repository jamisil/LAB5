package documin;

public interface Elemento {
//relevancia do elemento 
// propriedades do elemento
//valor do elemento 
	public String  RepresentacaoCompleta();
	public String RepresentacaoResumida();
	public int getPrioridade();
	
}
