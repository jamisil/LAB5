package documin;

/**
 * Representação da interface Elemento
 *
 * @author Jamilly Venâncio
 *
 */
public interface Elemento {

	public String RepresentacaoCompleta();

	public String RepresentacaoResumida();

	public double getPrioridade();

}
