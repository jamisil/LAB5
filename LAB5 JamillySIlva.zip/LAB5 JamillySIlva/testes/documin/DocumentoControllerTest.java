package documin;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class DocumentoControllerTest {
	private DocumentoController c;

	@BeforeEach
	void setUp() {
		this.c = new DocumentoController();
	}

	@Test
	void criaDocumentoController() {
		assertTrue(this.c.criarDocumento("Happy new year"));
	}

	@Test
	void criaDocumentosemtamanhoNomeInvalido() {
		try {
			c.criarDocumento(" ");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (IllegalArgumentException e) {
			assertEquals("Dados Inválidos", e.getMessage());
		}

	}

	@Test
	void criaDocumentocomtamanho() {
		assertTrue(c.criarDocumento("Receitas", 10));
	}

	@Test
	void criaDocumentocomtamanhoInvalido() {
		try {
			c.criarDocumento("Tarefas", 0);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (IllegalArgumentException e) {
			assertEquals("Dados Inválidos", e.getMessage());

		}
	}

	@Test
	void criaDocumentocomtamanhoInvalido1() {
		try {
			c.criarDocumento("Tarefas", 0);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (IllegalArgumentException e) {
			assertEquals("Dados Inválidos", e.getMessage());

		}
	}

	@Test
	void criaDocumentocomTamanhoNomeInvalido2() {
		try {
			c.criarDocumento("", 2);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (IllegalArgumentException e) {
			assertEquals("Dados Inválidos", e.getMessage());

		}
	}

	@Test
	void removerDocumento() {
		c.criarDocumento("Recortes");
		c.removerDocumento("Recortes");
		try {
			c.removerDocumento("Recortes");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (NoSuchElementException e) {
			assertEquals("Não existe", e.getMessage());
		}

	}

	@Test
	void ContaElementos1() {
		c.criarDocumento("Lazer");
		c.criarTexto("Lazer", "1", 3);
		assertEquals(1, c.contaelementos("Lazer"));
	}

	@Test
	void ContaElementosInvalido() {
		try {
			c.contaelementos("Músicas");
			fail("Deveria ter lançado excecao de dados inválido");
		} catch (NoSuchElementException e) {
			assertEquals("Não existe", e.getMessage());
		}
	}

	@Test
	void exibirDocumento() {
		c.criarDocumento("Fotos");
		c.criarLista("Fotos", "Exemplo | com umas dicas | de fotografia\n", 1, "|", "-");
		c.criarTexto("Fotos", "Luminosidade", 2);
		assertEquals("[Exemplo , com umas dicas , de fotografia\n" + ", Luminosidade]",
				Arrays.toString(c.exibirDocumento("Fotos")));
	}

	@Test
	void exibirDocumentoInvalidosemDocumento() {
		try {
			c.exibirDocumento("");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (NoSuchElementException e) {
			assertEquals("Não existe", e.getMessage());
		}
	}

	@Test
	void exibirDocumentosemElemento() {
		c.criarDocumento("Fotos");
		assertEquals("[]", Arrays.toString(c.exibirDocumento("Fotos")));
	}

	@Test
	void criaTexto() {
		c.criarDocumento("Praias");
		assertEquals(0, c.criarTexto("Praias", "Nordeste", 2));
	}

	@Test
	void criaTextosemDocumento() {
		try {
			c.criarTexto("Jogo", "Posições", 2);
			fail("Deveria ter lançado excecao de NoSuchElementException");
		} catch (NoSuchElementException e) {
			assertEquals("Documento não existe", e.getMessage());
		}
	}

	@Test
	void criaTextoDadosInvalidos1() {
		c.criarDocumento("Receitas");
		try {
			c.criarTexto("Receitas", "Ingredientes", 0);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (IllegalArgumentException e) {
			assertEquals("Dados inválidos", e.getMessage());
		}
	}

	@Test
	void criaTitulo() {
		c.criarDocumento("Aprendizado");
		assertEquals(0, c.criarTitulo("Aprendizado", "Metas", 4, 2, true));
	}

	@Test
	void criaTitulosemDocumento() {
		try {
			c.criarTitulo("Estudos", "disciplinas", 4, 1, false);
			fail("Deveria ter lançado excecao de NoSuchElementException");
		} catch (NoSuchElementException e) {
			assertEquals("Não existe documento", e.getMessage());
		}
	}

	@Test
	void criaTituloDadosInvalidos1() {
		c.criarDocumento("Receitas");
		try {
			c.criarTitulo("Receitas", "Disciplinas", 0, 0, false);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (IllegalArgumentException e) {
			assertEquals("Dados inválidos", e.getMessage());
		}
	}

	@Test
	void criaLista() {
		c.criarDocumento("Jogo");
		assertEquals(0, c.criarLista("Jogo", "Ataques | Defesas | Estratégias", 1, "|", "*"));
	}

	@Test
	void criaListasemDocumento() {
		try {
			c.criarLista("Defesas", "Correr | Esconder", 3, "|", "!");
			fail("Deveria ter lançado excecao de NoSuchElementException");
		} catch (NoSuchElementException e) {
			assertEquals("Não existe documento", e.getMessage());
		}
	}

	@Test
	void criaTermosemDocumento() {
		try {
			c.criarTermos("Esportes", "Voleibol | Futebol", 3, "|", "ALFABETICA");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (NoSuchElementException e) {
			assertEquals("Não existe documento", e.getMessage());
		}
	}

	@Test
	void criaTermosDadosInvalidos1() {
		c.criarDocumento("Jogo");
		try {
			c.criarTermos("Jogo", "", 2, "X", "NENHUM");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (IllegalArgumentException e) {
			assertEquals("Dados inválidos", e.getMessage());
		}
	}

	@Test
	void pegarRepresentacaoCompleta() {
		c.criarDocumento("Fotos");
		c.criarLista("Fotos", "Exemplo | com umas dicas | de fotografia\n", 1, "|", "-");
		c.criarTexto("Fotos", "Luminosidade", 2);
		assertEquals("Luminosidade", c.pegarRepresentacaoCompleta("Fotos", 1));

	}

	@Test
	void pegarRepresentacaoCompletasemDocumento() {
		try {
			c.pegarRepresentacaoCompleta("Notas", 3);
			fail("Deveria ter lançado excecao de NoSuchElementException");
		} catch (NoSuchElementException e) {
			assertEquals("Documento não existe", e.getMessage());
		}
	}

	@Test
	void pegarRepresentacaoResumida() {
		c.criarDocumento("Matemática");
		c.criarLista("Matemática", "Operações | Regra de tres ", 2, "|", "#");
		assertEquals("Operações , Regra de tres ", c.pegarRepresentacaoResumida("Matemática", 0));
	}

	@Test
	void pegarRepresentacaoResumidasemDocumento() {
		try {
			c.pegarRepresentacaoResumida("Músicas", 1);
			fail("Deveria ter lançado excecao de NoSuchElementException");
		} catch (Exception e) {
			assertEquals("Documento não existe", e.getMessage());
		}
	}

	@Test
	void apagarElemento() {
		c.criarDocumento("Receitas");
		c.criarTexto("Receitas", "ingredientes", 2);
		assertTrue(c.apagarElemento("Receitas", 0));
	}

	@Test
	void apagarelementoSemDocumento() {
		try {
			c.apagarElemento("Recortes", 0);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Não existe documento", e.getMessage());
		}

	}

	@Test
	void moverParaCima() {
		c.criarDocumento("Roupas");
		c.criarTexto("Roupas", "Camisas", 1);
		c.criarTexto("Roupas", "chapeu", 3);
		c.criarTexto("Roupas", "shorts", 4);
		c.moverParaCima("Roupas", 0);
		assertEquals("[Camisas, chapeu, shorts]", Arrays.toString(c.exibirDocumento("Roupas")));
	}

	@Test
	void moverParaBaixo() {
		c.criarDocumento("Roupas");
		c.criarTexto("Roupas", "Camisas", 1);
		c.criarTexto("Roupas", "shorts", 4);
		c.moverParaBaixo("Roupas", 1);
		assertEquals("[shorts, Camisas]", Arrays.toString(c.exibirDocumento("Roupas")));
	}

	@Test
	void criarAtalho() {
		c.criarDocumento("Google");
		c.criarTexto("Google", "email", 5);
		c.criarDocumento("Drive");
		c.criarTexto("Drive", "Ferramentas", 4);
		assertEquals(1, c.criarAtalho("Google", "Drive"));
	}

	@Test
	void criarVisaoCompleta() {
		c.criarDocumento("Roupas");
		c.criarTexto("Roupas", "Camisas", 1);
		c.criarTexto("Roupas", "shorts", 4);
		assertEquals(0, c.criarVisaoCompleta("Roupas"));

	}

	@Test
	void criarVisaoCompletasemDocumento() {
		try {
			c.criarVisaoCompleta("Material");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Documento não existe", e.getMessage());
		}

	}

	@Test
	void criarVisaoPrioritaria() {
		c.criarDocumento("Roupas");
		c.criarTexto("Roupas", "Camisas", 1);
		c.criarTexto("Roupas", "shorts", 4);
		c.criarDocumento("Google");
		c.criarTexto("Google", "email", 5);
		assertEquals(0, c.criarVisaoPrioritaria("Roupas", 5));
	}

	@Test
	void criarVisaoPrioritariasemDocumento() {
		try {
			c.criarVisaoPrioritaria("Material", 2);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Documento não existe ou não há elementos com tal prioridade", e.getMessage());
		}
	}

	@Test
	void criarVisaoTitulo() {
		c.criarDocumento("Metas");
		c.criarTitulo("Metas", "estudar mais", 2, 4, false);
		assertEquals(0, c.criarVisaoTitulo("Metas"));
	}

	@Test
	void criarVisaoTitulosemDocumento() {
		try {
			c.criarVisaoTitulo("Material");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Documento não existe ou não há elementos do tipo Titulo", e.getMessage());
		}
	}

	@Test
	void exibirVisao() {
		c.criarDocumento("Roupas");
		c.criarTexto("Roupas", "Camisas", 1);
		c.criarTexto("Roupas", "shorts", 4);
		c.criarVisaoCompleta("Roupas");
		assertEquals("[Camisas, shorts]", Arrays.toString(c.exibirVisao(0)));
	}

	@Test
	void exibirVisaosemDocumento() {
		try {
			c.exibirVisao(1);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Visão não existe", e.getMessage());
		}
	}
}
