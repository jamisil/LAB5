package documin;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TituloTest {

	@Test
	void criaTitulo() {
		Titulo t = new Titulo("Receitas", 2, 5, true);
		assertEquals("5.Receitas", t.RepresentacaoResumida());
	}

	@Test
	void criaTituloinvalido1() {
		try {
			new Titulo("", 1, 7, false);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Dados Inválidos", e.getMessage());
		}
	}

	@Test
	void criaTituloInvalido2() {
		try {
			new Titulo("Tarefas", 0, 7, false);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Dados Inválidos", e.getMessage());
		}
	}

	@Test
	void representacaoCompleta() {
		Titulo t = new Titulo("Feira", 4, 9, true);
		assertEquals("9.Feira--\n" + "9-FEIRA", t.RepresentacaoCompleta());
	}

	@Test
	void representacaoCompletainvalido() {
		try {
			new Titulo("", 2, 4, true);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Dados Inválidos", e.getMessage());
		}
	}

	@Test
	void representacaoResumida() {
		Titulo t = new Titulo("Estratégias", 3, 9, true);
		assertEquals("9.Estratégias", t.RepresentacaoResumida());
	}

	@Test
	void representacaoResumindaInvalido() {
		try {
			new Titulo("Feira", 6, 4, true);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Dados Inválidos", e.getMessage());
		}
	}

	@Test
	void getPrioridade() {
		Titulo t = new Titulo("Jogos", 3, 1, true);
		assertEquals(3, t.getPrioridade());
	}

	@Test
	void getPrioridadeInvalido() {
		try {
			new Titulo("Feira", 0, 4, true);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Dados Inválidos", e.getMessage());
		}
	}
}
