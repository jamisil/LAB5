package documin;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Arrays;
import java.util.NoSuchElementException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class FacedeTest {
	private Facade f;

	@BeforeEach
	void setUp() {
		this.f = new Facade();
	}

	@Test
	void criaDocumentosemtamanho() {
		assertTrue(f.criarDocumento("Programacao"));
	}

	@Test
	void criaDocumentosemtamanhoNomeInvalido() {
		Facade f = new Facade();
		try {
			f.criarDocumento(" ");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (IllegalArgumentException e) {
			assertEquals("Dados Inválidos", e.getMessage());
		}

	}

	@Test
	void criaDocumentocomtamanho() {
		assertTrue(f.criarDocumento("Receitas", 10));
	}

	@Test
	void criaDocumentocomtamanhoInvalido() {
		try {
			f.criarDocumento("Tarefas", 0);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (IllegalArgumentException e) {
			assertEquals("Dados Inválidos", e.getMessage());

		}
	}

	@Test
	void criaDocumentocomTamanhoNomeInvalido() {
		try {
			f.criarDocumento("", 2);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (IllegalArgumentException e) {
			assertEquals("Dados Inválidos", e.getMessage());

		}
	}

	@Test
	void removerDocumento() {
		f.criarDocumento("Recortes");
		f.removerDocumento("Recortes");
		try {
			f.removerDocumento("Recortes");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (NoSuchElementException e) {
			assertEquals("Não existe", e.getMessage());
		}

	}

	@Test
	void removerDocumento1() {
		try {
			f.removerDocumento("Recortes");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (NoSuchElementException e) {
			assertEquals("Não existe", e.getMessage());
		}

	}

	@Test
	void ContaElementos1() {
		f.criarDocumento("Lazer");
		f.criarTexto("Lazer", "1", 3);
		assertEquals(1, f.contarElementos("Lazer"));
	}

	@Test
	void ContaElementosInvalido() {
		try {
			f.contarElementos("Músicas");
			fail("Deveria ter lançado excecao de dados inválido");
		} catch (NoSuchElementException e) {
			assertEquals("Não existe", e.getMessage());
		}

	}

	@Test
	void exibirDocumento() {
		f.criarDocumento("Fotos");
		f.criarLista("Fotos", "Exemplo | com umas dicas | de fotografia\n", 1, "|", "-");
		f.criarTexto("Fotos", "Luminosidade", 2);
		assertEquals("[Exemplo , com umas dicas , de fotografia\n" + ", Luminosidade]",
				Arrays.toString(f.exibirDocumento("Fotos")));
	}

	@Test
	void exibirDocumentoInvalidosemDocumento() {
		try {
			f.exibirDocumento("");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (NoSuchElementException e) {
			assertEquals("Não existe", e.getMessage());
		}
	}

	@Test
	void exibirDocumentosemElemento() {
		f.criarDocumento("Fotos");
		assertEquals("[]", Arrays.toString(f.exibirDocumento("Fotos")));
	}

	@Test
	void criaTexto() {
		f.criarDocumento("Praias");
		assertEquals(0, f.criarTexto("Praias", "Nordeste", 2));
	}

	@Test
	void criaTextosemDocumento() {
		try {
			f.criarTexto("Jogo", "Posições", 2);
			fail("Deveria ter lançado excecao de NoSuchElementException");
		} catch (NoSuchElementException e) {
			assertEquals("Documento não existe", e.getMessage());
		}
	}

	@Test
	void criaTextoDadosInvalidos1() {
		f.criarDocumento("Receitas");
		try {
			f.criarTexto("Receitas", "Ingredientes", 0);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (IllegalArgumentException e) {
			assertEquals("Dados inválidos", e.getMessage());
		}
	}

	@Test
	void criaTextoDadosInvalidos2() {
		f.criarDocumento("Receitas");
		try {
			f.criarTexto("Receitas", "", 2);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (IllegalArgumentException e) {
			assertEquals("Dados inválidos", e.getMessage());
		}
	}

	@Test
	void criaTitulo() {
		f.criarDocumento("Aprendizado");
		assertEquals(0, f.criarTitulo("Aprendizado", "Metas", 4, 2, true));
	}

	@Test
	void criaTitulosemDocumento() {
		try {
			f.criarTitulo("Estudos", "disciplinas", 4, 1, false);
			fail("Deveria ter lançado excecao de NoSuchElementException");
		} catch (NoSuchElementException e) {
			assertEquals("Não existe documento", e.getMessage());
		}
	}

	@Test
	void criaTituloDadosInvalidos1() {
		f.criarDocumento("Receitas");
		try {
			f.criarTitulo("Receitas", "Disciplinas", 0, 0, false);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (IllegalArgumentException e) {
			assertEquals("Dados inválidos", e.getMessage());
		}
	}

	@Test
	void criaTituloDadosInvalidos2() {
		f.criarDocumento("Aprendizado");
		try {
			f.criarTitulo("Aprendizado", " ", 4, 5, false);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (IllegalArgumentException e) {
			assertEquals("Dados inválidos", e.getMessage());
		}
	}

	@Test
	void criaLista() {
		f.criarDocumento("Jogo");
		assertEquals(0, f.criarLista("Jogo", "Ataques | Defesas | Estratégias", 1, "|", "*"));
	}

	@Test
	void criaListasemDocumento() {
		try {
			f.criarLista("Defesas", "Correr | Esconder", 3, "|", "!");
			fail("Deveria ter lançado excecao de NoSuchElementException");
		} catch (NoSuchElementException e) {
			assertEquals("Não existe documento", e.getMessage());
		}
	}

	@Test
	void criaListaDadosInvalidos1() {
		f.criarDocumento("Jogo");
		try {
			f.criarLista("Jogo", "Correr | Esconder", 6, "|", "@");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (IllegalArgumentException e) {
			assertEquals("Dados inválidos", e.getMessage());
		}
	}

	@Test
	void criaListaDadosInvalidos2() {
		f.criarDocumento("Jogo");
		try {
			f.criarLista("Jogo", "", 4, "", "!");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (IllegalArgumentException e) {
			assertEquals("Dados inválidos", e.getMessage());
		}
	}

	@Test
	void criaTermosemDocumento() {
		try {
			f.criarTermos("Esportes", "Voleibol | Futebol", 3, "|", "ALFABETICA");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (NoSuchElementException e) {
			assertEquals("Não existe documento", e.getMessage());
		}
	}

	@Test
	void criaTermosDadosInvalidos1() {
		f.criarDocumento("Jogo");
		try {
			f.criarTermos("Jogo", "", 2, "X", "NENHUM");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (IllegalArgumentException e) {
			assertEquals("Dados inválidos", e.getMessage());
		}
	}

	@Test
	void criaTermosDadosInvalidos2() {
		f.criarDocumento("Notas");
		try {
			f.criarTermos("Notas", "Buscar frango , pintar desenho , comer goiabada, passar em FMCC", 3, ",", "");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (IllegalArgumentException e) {
			assertEquals("Dados inválidos", e.getMessage());
		}
	}

	@Test
	void pegarRepresentacaoCompleta() {
		f.criarDocumento("Fotos");
		f.criarLista("Fotos", "Exemplo | com umas dicas | de fotografia\n", 1, "|", "-");
		f.criarTexto("Fotos", "Luminosidade", 2);
		assertEquals("Luminosidade", f.pegarRepresentacaoCompleta("Fotos", 1));

	}

	@Test
	void pegarRepresentacaoCompletasemDocumento() {
		try {
			f.pegarRepresentacaoCompleta("Notas", 3);
			fail("Deveria ter lançado excecao de NoSuchElementException");
		} catch (NoSuchElementException e) {
			assertEquals("Documento não existe", e.getMessage());
		}
	}

	@Test
	void pegarRepresentacaoCompletaDadosInvalidos1() {
		f.criarDocumento("Caderno");
		try {
			f.pegarRepresentacaoCompleta("Caderno", 0);
		} catch (Exception e) {
			assertEquals("Dado inválido", e.getMessage());
		}
	}

	@Test
	void pegarRepresentacaoCompletaDadosInvalidos2() {
		f.criarDocumento("Músicas");
		f.criarTexto("Músicas", "Notas musicais", 3);
		try {
			f.pegarRepresentacaoCompleta("Músicas", 1);
			fail("Deveria ter lançado excecao de NoSuchElementException");
		} catch (Exception e) {
			assertEquals("Dado inválido", e.getMessage());
		}
	}

	@Test
	void pegarRepresentacaoResumida() {
		f.criarDocumento("Matemática");
		f.criarLista("Matemática", "Operações | Regra de tres ", 2, "|", "#");
		assertEquals("Operações , Regra de tres ", f.pegarRepresentacaoResumida("Matemática", 0));
	}

	@Test
	void pegarRepresentacaoResumidasemDocumento() {
		try {
			f.pegarRepresentacaoResumida("Músicas", 1);
			fail("Deveria ter lançado excecao de NoSuchElementException");
		} catch (Exception e) {
			assertEquals("Documento não existe", e.getMessage());
		}
	}

	@Test
	void pegarRepresentacaoResumidaDadoInvalido() {
		f.criarDocumento("Cadeados");
		try {
			f.pegarRepresentacaoCompleta("Cadeados", 0);
		} catch (Exception e) {
			assertEquals("Dado inválido", e.getMessage());
		}
	}

	@Test
	void apagarElemento() {
		f.criarDocumento("Receitas");
		f.criarTexto("Receitas", "ingredientes", 2);
		assertTrue(f.apagarElemento("Receitas", 0));
	}

	@Test
	void apagarelementoSemDocumento() {
		try {
			f.apagarElemento("Recortes", 0);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Não existe documento", e.getMessage());
		}

	}

	@Test
	void apagarelementoDadoInvalido() {
		f.criarDocumento("Cadeados");
		try {
			f.pegarRepresentacaoCompleta("Cadeados", 0);
		} catch (Exception e) {
			assertEquals("Dado inválido", e.getMessage());
		}
	}

	@Test
	void moverParaCima() {
		f.criarDocumento("Roupas");
		f.criarTexto("Roupas", "Camisas", 1);
		f.criarTexto("Roupas", "chapeu", 3);
		f.criarTexto("Roupas", "shorts", 4);
		f.moverParaCima("Roupas", 0);
		assertEquals("[Camisas, chapeu, shorts]", Arrays.toString(f.exibirDocumento("Roupas")));
	}

	@Test
	void moverParaBaixo() {
		f.criarDocumento("Roupas");
		f.criarTexto("Roupas", "Camisas", 1);
		f.criarTexto("Roupas", "shorts", 4);
		f.moverParaBaixo("Roupas", 1);
		assertEquals("[shorts, Camisas]", Arrays.toString(f.exibirDocumento("Roupas")));
	}

	@Test
	void criarAtalho() {
		f.criarDocumento("Google");
		f.criarTexto("Google", "email", 5);
		f.criarDocumento("Drive");
		f.criarTexto("Drive", "Ferramentas", 4);
		assertEquals(1, f.criarAtalho("Google", "Drive"));
	}

	@Test
	void criarAtalhosemDocumento() {
		try {
			f.criarAtalho("Folhaem", "Especie");
		} catch (Exception e) {
			assertEquals("Documento não existe ou não pode ser referenciado", e.getMessage());
		}

	}

	@Test
	void criarVisaoCompleta() {
		f.criarDocumento("Roupas");
		f.criarTexto("Roupas", "Camisas", 1);
		f.criarTexto("Roupas", "shorts", 4);
		assertEquals(0, f.criarVisaoCompleta("Roupas"));

	}

	@Test
	void criarVisaoCompletasemDocumento() {
		try {
			f.criarVisaoCompleta("Material");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Documento não existe", e.getMessage());
		}

	}

	@Test
	void criarVisaoPrioritaria() {
		f.criarDocumento("Roupas");
		f.criarTexto("Roupas", "Camisas", 1);
		f.criarTexto("Roupas", "shorts", 4);
		f.criarDocumento("Google");
		f.criarTexto("Google", "email", 5);
		assertEquals(0, f.criarVisaoPrioritaria("Roupas", 5));
	}

	@Test
	void criarVisaoPrioritariasemDocumento() {
		try {
			f.criarVisaoPrioritaria("Material", 2);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Documento não existe ou não há elementos com tal prioridade", e.getMessage());
		}
	}

	@Test
	void criarVisaoTitulo() {
		f.criarDocumento("Metas");
		f.criarTitulo("Metas", "estudar mais", 2, 4, false);
		assertEquals(0, f.criarVisaoTitulo("Metas"));
	}

	@Test
	void criarVisaoTitulosemDocumento() {
		try {
			f.criarVisaoTitulo("Material");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Documento não existe ou não há elementos do tipo Titulo", e.getMessage());
		}
	}

	@Test
	void exibirVisao() {
		f.criarDocumento("Roupas");
		f.criarTexto("Roupas", "Camisas", 1);
		f.criarTexto("Roupas", "shorts", 4);
		f.criarVisaoCompleta("Roupas");
		assertEquals("[Camisas, shorts]", Arrays.toString(f.exibirVisao(0)));
	}

	@Test
	void exibirVisaosemDocumento() {
		try {
			f.exibirVisao(1);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Visão não existe", e.getMessage());
		}
	}

}
