package documin;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TextoTest {

	@Test
	void criaTexto() {
		Texto t = new Texto("Cores", 2);
		assertEquals("Cores", t.RepresentacaoResumida());
	}

	@Test
	void criaTextoInvalido1() {
		try {
			new Texto("", 4);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Dados Inválidos", e.getMessage());
		}
	}

	@Test
	void criaTextoInvalido2() {
		try {
			new Texto("Combinações", 0);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Dados Inválidos", e.getMessage());
		}
	}

	@Test
	void representaçãoCompleta() {
		Texto t = new Texto("Brinquedos", 3);
		assertEquals("Brinquedos", t.RepresentacaoCompleta());
	}

	@Test
	void representacaoCompletaInvalida() {
		try {
			new Texto("", 3);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Dados Inválidos", e.getMessage());
		}
	}

	@Test
	void representacaoResumida() {
		Texto t = new Texto("Teclado", 3);
		assertEquals("Teclado", t.RepresentacaoResumida());
	}

	@Test
	void representacaoResumidaInvalido1() {
		try {
			new Texto("Combinações", 6);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Dados Inválidos", e.getMessage());
		}
	}

	@Test
	void representacaoResumidaInvalido2() {
		try {
			new Texto("", 3);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Dados Inválidos", e.getMessage());
		}
	}

	@Test
	void getPrioridade() {
		Texto t = new Texto("Histórias", 3);
		assertEquals(3.0, t.getPrioridade());
	}

	@Test
	void getPrioridadeInvalido() {
		try {
			new Texto("Pintura", 0);
		} catch (Exception e) {
			assertEquals("Dados Inválidos", e.getMessage());
		}
	}
}
