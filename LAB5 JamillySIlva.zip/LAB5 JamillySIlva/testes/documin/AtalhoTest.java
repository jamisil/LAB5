package documin;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AtalhoTest {

	@BeforeEach
	void setUp() throws Exception {
	}

	@Test
	void criaAtalho() {
		Documento d = new Documento("Google");
		d.criaTexto("email", 5);
		Documento de = new Documento("Drive");
		de.criaTexto("Ferramentas", 4);
		assertEquals(1, d.criarAtalho("Google", d.calculaMedia(), de.getTitulo(), de.pegarRepresentacaoCompletaAtalho(),
				de.pegarRepresentacaoResumidaAtalho()));
	}

	@Test
	void criaAtalhoInválido() {
		Documento d = new Documento("Google");
		d.criaTexto("email", 5);
		Documento de = new Documento("Drive");
		de.criaTexto("Ferramentas", 4);
		try {
			d.criarAtalho("", d.calculaMedia(), de.getTitulo(), de.pegarRepresentacaoCompletaAtalho(),
					de.pegarRepresentacaoResumidaAtalho());
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Dados Inválidos", e.getMessage());
		}
	}

	@Test
	void RepresentacaoCompleta() {
		Documento d = new Documento("Google");
		d.criaTexto("email", 5);
		Documento de = new Documento("Drive");
		de.criaTexto("Ferramentas", 4);
		assertEquals("email", d.pegarRepresentacaoCompletaAtalho());
	}

	@Test
	void RepresentacaoResumida() {
		Documento d = new Documento("Google");
		d.criaTexto("email", 5);
		Documento de = new Documento("Drive");
		de.criaTexto("Ferramentas", 4);
		assertEquals("email", d.pegarRepresentacaoResumidaAtalho());
	}

	@Test
	void pegarPrioridade() {
		Documento d = new Documento("Google");
		d.criaTexto("email", 5);
		Documento de = new Documento("Drive");
		de.criaTexto("Ferramentas", 4);
		Atalho a = new Atalho("Google", d.calculaMedia(), de.getTitulo(), de.pegarRepresentacaoCompletaAtalho(),
				de.pegarRepresentacaoResumidaAtalho());
		assertEquals(5.0, a.getPrioridade());
	}

}
