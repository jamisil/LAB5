package documin;

import java.util.ArrayList;
import java.util.LinkedList;

public class teste {

	public static void main(String[] args) {
		Facade f = new Facade();
		DocumentoController doc = new DocumentoController();
		System.out.println(f.criarDocumento("areai"));
		Titulo t = new Titulo("Documentos Texto",1,1,true);
	//	System.out.println(t.RepresentacaoResumida());
		Texto tr = new Texto("string",2);
		//System.out.println(tr.RepresentacaoResumida());
		Lista l = new Lista("Exemplo|de uma lista|de 3 termos",2,"|","-");
		System.out.println(l.RepresentacaoCompleta());
		System.out.println(l.RepresentacaoResumida());
		System.out.println(doc.criarDocumento("jaka", 1));
		Termos r = new Termos("Teste / termos / Aleatórios",3,"/","ALFABETICA");
		System.out.println(r.RepresentacaoCompleta());
		//Texto t = new Texto("string",1);
		LinkedList a = new LinkedList<Texto>();
		Object obj = tr;
		
		

	}

}
