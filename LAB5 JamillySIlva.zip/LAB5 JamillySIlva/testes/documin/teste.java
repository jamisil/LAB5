package documin;

import java.util.ArrayList;
import java.util.LinkedList;

public class teste {

	public static void main(String[] args) {
		Facade f = new Facade();
		DocumentoController doc = new DocumentoController();
		System.out.println(f.criarDocumento("areai"));
		//Titulo t = new Titulo("Documentos Texto",1,true);
		//System.out.println(t.representacaoCompleta());
		Texto tr = new Texto("string",2);
		System.out.println(tr.representacaoResumida());
		Lista l = new Lista("Exemplo | de uma lista | de 3 termos",2,"|","-");
		System.out.println(l.representacaocompleta());
		System.out.println(l.representacaoresumida());
		System.out.println(doc.criarDocumento("jaka", 1));
	
		Texto t = new Texto("string",1);
		LinkedList a = new LinkedList<Texto>();
		Object obj = tr;
		System.out.println(a.getClass());
		System.out.println(a.add(t));
		System.out.println(a.add(tr));
		System.out.println(a.size());
		System.out.println(a.toString());
		System.out.println(a.remove(1));
		System.out.println(a.clone().toString());

		

	}

}
