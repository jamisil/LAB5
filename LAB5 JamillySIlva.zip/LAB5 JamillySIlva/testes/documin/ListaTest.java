package documin;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class ListaTest {

	@Test
	void criaLista() {
		Lista l = new Lista("Ataques | Defesas | Estratégias", 1, "|", "*");
		assertEquals("Ataques , Defesas , Estratégias", l.RepresentacaoResumida());
	}

	@Test
	void criaListaInvalido1() {
		try {
			new Lista("", 2, "!", "*");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Dados inválidos", e.getMessage());

		}
	}

	@Test
	void criaListaInvalido2() {
		try {
			new Lista("Ataques/Defesas", 7, "!", "*");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Dados inválidos", e.getMessage());

		}
	}

	@Test
	void Representacaocompleta() {
		Lista l = new Lista("Ataques | Defesas | Estratégias", 1, "|", "*");
		assertEquals("Ataques , Defesas , Estratégias", l.RepresentacaoResumida());
	}

	@Test
	void representacaoCompletaInvalida() {
		try {
			new Lista("Ataques/Defesas", 4, "", "");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (IllegalArgumentException e) {
			assertEquals("Dados inválidos", e.getMessage());

		}

	}

	@Test
	void representacaoResumida() {
		Lista l = new Lista("Posição*JOgadores", 4, "*", "!");
		assertEquals("Posição,JOgadores", l.RepresentacaoResumida());

	}

	@Test
	void getPrioridade() {
		Lista l = new Lista("Desenhos+Jogos", 2, "+", "/");
		assertEquals(2.0, l.getPrioridade());

	}

	@Test
	void getPrioridadeInvalido() {
		try {
			new Lista("Desenhos+Jogos", 9, "+", "/");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (IllegalArgumentException e) {
			assertEquals("Dados inválidos", e.getMessage());
		}
	}
}
