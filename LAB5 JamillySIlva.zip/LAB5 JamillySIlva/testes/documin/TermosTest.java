package documin;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TermosTest {

	@BeforeEach
	void setUp() throws Exception {
	}

	@Test
	void criaTermo() {
		Termos t = new Termos("Voleibol & Futebol", 3, "&", "ALFABETICA");
		assertEquals("Total termos: 2\n" + "- Futebol,Voleibol ", (t.RepresentacaoCompleta()));
	}

	@Test
	void criaTermoInvalido1() {
		try {
			new Termos("", 1, "!", "ALFABETICA");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Dados Inválidos", e.getMessage());
		}
	}

	@Test
	void criaTermoInvalido2() {
		try {
			new Termos("Esportes % LAZER", 5, "%", "");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Dados Inválidos", e.getMessage());
		}
	}

	@Test
	void RepresentacaoCompleta() {
		Termos t = new Termos("Operações _ Regra de tres ", 3, "_", "ALFABETICA");
		assertEquals("Total termos: 2\n" + "- Regra de tres ,Operações ", t.RepresentacaoCompleta());
	}

	@Test
	void RepresentacaoCompletaInvalida() {
		try {
			new Termos("Tarefas # Metas", 6, "#", "ALFABETICA");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Dados Inválidos", e.getMessage());
		}
	}

	@Test
	void RepresentacaoResumida() {
		Termos t = new Termos("Tarefas # Metas", 5, "#", "ALFABETICA");
		assertEquals(" Metas#Tarefas ", t.RepresentacaoResumida());
	}

	@Test
	void RepresentacaoResumidaInvalida() {
		try {
			new Termos("Operações _ Regra de tres ", 3, "", "ALFABETICA");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Dados Inválidos", e.getMessage());
		}
	}

	@Test
	void pegarPrioridade() {
		Termos t = new Termos("Voleibol & Futebol", 3, "&", "ALFABETICA");
		assertEquals(3, t.getPrioridade());
	}

	@Test
	void pegarPrioridadeInvalido() {
		try {
			new Termos("Linhas X colunas", -1, "X", "ALFABETICA");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Dados Inválidos", e.getMessage());
		}
	}
}
