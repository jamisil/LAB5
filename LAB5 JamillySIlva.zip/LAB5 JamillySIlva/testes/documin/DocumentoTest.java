package documin;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Arrays;


import org.junit.jupiter.api.Test;

class DocumentoTest {

	@Test
	void criaDocumentosemtamanho() {
		Documento doc = new Documento("Ferramentas");
		assertEquals("Ferramentas", doc.getTitulo());
	}

	@Test
	void criaDocumentocomTamanho() {
		Documento doc = new Documento("Profissões", 2);
		assertEquals("Profissões", doc.getTitulo());
	}

	@Test
	void testacapacidadeDocumentocomTamanho() {
		Documento doc = new Documento("Receitas", 2);
		doc.criaTexto("Farinha", 2);
		doc.criaTitulo("Forno", 3, 4, true);
		try {
			doc.criaTexto("Manteiga", 2);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (IllegalArgumentException e) {
			assertEquals("Atingiu limite", e.getMessage());
		}
	}

	@Test
	void criaDocumentosemTitulo() {
		try {
			new Documento("");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (IllegalArgumentException e) {
			assertEquals("Dados Inválidos", e.getMessage());
		}
	}

	@Test
	void criaDocumentosemTituloecomTamanho() {
		try {
			new Documento("", 4);
			fail("Deveria ter lançado excecao de dados inválidos");
		} catch (IllegalArgumentException e) {
			assertEquals("Dados Inválidos", e.getMessage());
		}
	}

	@Test
	void criaDocumentocomtituloecomTamanhoInvalido() {
		try {
			new Documento("Gratificação", 0);
			fail("Deveria ter lançado excecao de dados inválidos");
		} catch (IllegalArgumentException e) {
			assertEquals("Dados Inválidos", e.getMessage());
		}
	}

	@Test
	void criaDocumentoAdicionaElementos() {
		Documento doc = new Documento("Profissões", 2);
		doc.criaTexto("faca", 4);
		doc.criaTexto("ice", 5);
		assertEquals("[faca, ice]", Arrays.toString(doc.representacaoDocumento()));
	}

	@Test
	void numerodeelemento() {
		Documento doc = new Documento("facas", 8);
		assertEquals(0, doc.getElementos().size());
	}

	@Test
	void numeroelemento() {
		Documento doc = new Documento("facas");
		doc.criaTexto("Regua", 4);
		assertEquals(1, doc.getElementos().size());
	}

	@Test
	void getnumeroelementos() {
		Documento doc = new Documento("ecossitema");
		doc.criaLista("Exemplo | de lista", 2, "|", "-");
		doc.criaTitulo("Receitas", 1, 4, false);
		assertEquals(2, doc.getElementos().size());
	}

	@Test
	void RepresentacaoDocumento() {
		Documento docref = new Documento("facas");
		docref.criaLista("Exemplo | de lista", 2, "|", "-");
		docref.criaTitulo("Receitas", 1, 4, false);
		// doc.criarAtalho("ecossistemas",docref.calculaMedia(),docref.getTitulo(),
		// docref.pegarRepresentacaoCompletaAtalho(),docref.pegarRepresentacaoResumidaAtalho());
		assertEquals("[Exemplo , de lista, 4.Receitas]", Arrays.toString(docref.representacaoDocumento()));
	}

	@Test
	void RepresentacaoDocumentoVazio() {
		Documento doc = new Documento("Biomas");
		// doc.criarAtalho("Biomas",doc.calculaMedia() ,doc.getTitulo(),
		// doc.pegarRepresentacaoCompletaAtalho(),
		// doc.pegarRepresentacaoResumidaAtalho());
		assertEquals("[]", Arrays.toString(doc.representacaoDocumento()));

	}

	@Test
	void criaTexto() {
		Documento d = new Documento("Praias");
		assertEquals(0, d.criaTexto("Nordeste", 2));
	}

	@Test
	void criaTextoDadosInvalido1() {
		Documento d = new Documento("Teclado");
		try {
			d.criaTexto("Mouse", 0);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (IllegalArgumentException e) {
			assertEquals("Dados Inválidos", e.getMessage());
		}
	}

	@Test
	void criaTextoDadoInvalido2() {
		Documento d = new Documento("Teclado");
		try {
			d.criaTexto("", 2);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (IllegalArgumentException e) {
			assertEquals("Dados Inválidos", e.getMessage());
		}
	}

	@Test
	void criaTextoDadoInvalido3() {
		Documento d = new Documento("Monitor", 1);
		d.criaTexto("Mouse", 1);
		try {
			d.criaTexto("Teclado", 2);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Atingiu limite", e.getMessage());
		}
	}

	@Test
	void criaTitulo() {
		Documento d = new Documento("Aprendizado");
		assertEquals(0, d.criaTitulo("Metas", 4, 2, true));
	}

	@Test
	void criaTituloDadosInvalido1() {
		Documento d = new Documento("Estudos");
		try {
			d.criaTitulo("disciplinas", 5, 0, false);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Dados Inválidos", e.getMessage());
		}
	}

	@Test
	void criaTituloDadosInvalidos2() {
		Documento d = new Documento("Estudos");
		try {
			d.criaTitulo("", 3, 1, false);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Dados Inválidos", e.getMessage());
		}
	}

	@Test
	void criaTituloDadosInvalidos3() {
		Documento d = new Documento("Estudos", 1);
		d.criaTitulo("notas", 3, 1, false);
		try {
			d.criaTitulo("disciplinas", 5, 2, false);
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Atingiu limite", e.getMessage());
		}
	}

	@Test
	void criaLista() {
		Documento d = new Documento("Jogo");
		assertEquals(0, d.criaLista("Ataques | Defesas | Estratégias", 1, "|", "*"));
	}

	@Test
	void criaListaDadosInvalido1() {
		Documento d = new Documento("Jogo");
		try {
			d.criaLista("", 1, "|", "*");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Dados inválidos", e.getMessage());
		}
	}

	@Test
	void criaListaDadosInvalido2() {
		Documento d = new Documento("Jogo");
		try {
			d.criaLista("Ataques | Defesas | Estratégias", 0, "|", "*");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Dados inválidos", e.getMessage());
		}
	}

	@Test
	void criaListaDadosInvalido3() {
		Documento d = new Documento("Jogo", 1);
		try {
			d.criaLista("disciplinas", 4, "", "!");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Dados inválidos", e.getMessage());
		}
	}

	@Test
	void criaTermos() {
		Documento d = new Documento("Lazer");
		assertEquals(0, d.criaTermos("Voleibol | Futebol", 3, "|", "ALFABETICA"));
	}

	@Test
	void criaTermosInvalido1() {
		Documento d = new Documento("Lazer");
		try {
			d.criaTermos("Voleibol | Futebol", 3, "", "ALFABETICA");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Dados Inválidos", e.getMessage());
		}
	}

	@Test
	void criaTermosInvalido2() {
		Documento d = new Documento("Lazer");
		try {
			d.criaTermos("Voleibol | Futebol", 3, "|", "");
			fail("Deveria ter lancado excecao de dados inválido");
		} catch (Exception e) {
			assertEquals("Dados Inválidos", e.getMessage());
		}
	}
	@Test
	void pegarRepresentacaoCompleta() {
		Documento d = new Documento("Fotos");
		d.criaLista("Exemplo | com umas dicas | de fotografia\n", 1, "|", "-");
		d.criaTexto("Luminosidade", 2);
		assertEquals("Luminosidade",d.pegarRepresentacaoCompleta(1));
	}
	@Test
	void pegarRepresentacaoResumida() {
		Documento d = new Documento("Fotos");
		d.criaLista("Exemplo # com umas dicas # de fotografia\n", 1, "#", "-");
		d.criaTexto("Luminosidade", 2);
		assertEquals("Luminosidade", d.pegarRepresentacaoResumida(1));
	}
	
	@Test
	void moverparacima() {
		Documento d = new Documento("Roupas");
		d.criaTexto("Camisas", 1);
		d.criaTexto( "chapeu", 3);
		d.criaTexto("shorts", 4);
		d.movereParaCima(0);
		assertEquals("[Camisas, chapeu, shorts]",Arrays.toString(d.representacaoDocumento()));

	}
	@Test
	void apagarelemento() {
		Documento d = new Documento("Receitas");
		d.criaTexto( "ingredientes", 2);
		assertTrue(d.apagarelementoDocumento(0));
	}
	@Test
	void calculamedia() {
		Documento d = new Documento("Fotografia");
		d.criaTexto("Camisas", 1);
		d.criaTexto( "chapeu", 3);
		d.criaTexto("shorts", 4);
		assertEquals(2.6666666666666665,d.calculaMedia());
		
	}
	@Test
	void pegarRepresentacaoCompletaAtalho() {
		Documento d = new Documento("Google");
		d.criaTexto( "email", 5);
		Documento de = new Documento("Drive");
		de.criaTexto("Ferramentas", 4);
		de.criarAtalho("Drive",5 , "Google", d.pegarRepresentacaoCompletaAtalho(), d.pegarRepresentacaoResumidaAtalho());
		assertEquals("Ferramentas",de.pegarRepresentacaoCompletaAtalho());
		
	}
	@Test
	void criarVisaoCompleta() {
		Documento d = new Documento("Roupas");
		d.criaTexto( "Camisas", 1);
		d.criaTexto("shorts", 4);
		assertEquals("[Camisas, shorts]",Arrays.toString(d.criarVisaoCompleta()));
	}
	@Test
	void criarVisaoResumida() {
		Documento d = new Documento("Roupas");
		d.criaTexto("Camisas", 1);
		d.criaTexto("shorts", 4);
		assertEquals("[Camisas, shorts]", Arrays.toString(d.criarVisaoResumida()));
	}
	@Test
	void criarVisaoPrioritaria() {
		Documento d = new Documento("Roupas");
		d.criaTexto("Camisas", 1);
		d.criaTexto("shorts",4);
		assertEquals("[Camisas, null]",Arrays.toString(d.criarVisaoPrioritaria(1)));
	}
	@Test
	void criarVisaoTitulo() {
		Documento d = new Documento("Roupas");
		d.criaTitulo("Camisas",1,1,true);
		d.criaTexto("shorts",4);
		assertEquals("[1.Camisas, null]",Arrays.toString(d.criarVisaoTitulo()));
	}
}
