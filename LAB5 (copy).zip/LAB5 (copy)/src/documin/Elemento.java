package documin;

public interface Elemento {
//relevancia do elemento 
// propriedades do elemento
//valor do elemento 
}
