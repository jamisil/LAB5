package documin;

import java.lang.reflect.Array;
import java.util.Arrays;

public class Termos {
	//private String tituloDoc;
	private String valorTermos;
	//private int prioridade;
	private String separador;
	private String ordem;
	
	public Termos(String valorTermos,String separador, String ordem) {
		this.valorTermos = valorTermos;
		//this.prioridade = prioridade;
		this.separador = separador;
		this.ordem = ordem;
	}
	
	public int contador() {
		int cont = this.valorTermos.split(separador).length;
		return cont;
	}
	public String representacaoCompleta() {
		String[] a = this.valorTermos.split(separador);
		Arrays.sort(a);
	//	String representacaocompleta = "Total termos:" + contador() + "\n";
		//String representacao = this.valorTermos.replace(" ", "");
		//representacaocompleta +=  "-" + representacao.replace(separador, ",");
		//return representacaocompleta;
		return a[0];
	}
}
