package documin;

public class Facade {

	private DocumentoController documentoController;

	public Facade() {
		// // exemplo de chamada no construtor:
		this.documentoController = new DocumentoController();
	}

	public boolean criarDocumento(String titulo) {
		return this.documentoController.criarDocumento(titulo);
	}

	public boolean criarDocumento(String titulo, int tamanho) {
		return this.documentoController.criarDocumento(titulo, tamanho);
	}

	public void removerDocumento(String titulo) {
		this.documentoController.removerDocumento(titulo);
	}

	public int contarElementos(String titulo) {
		return this.documentoController.contaelementos(titulo);

	}

	public String[] exibirDocumento(String titulo) {
		return this.documentoController.exibirDocumento(titulo);
	}

}