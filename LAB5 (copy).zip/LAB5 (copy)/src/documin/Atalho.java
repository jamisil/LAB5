package documin;

public class Atalho {
	private int prioridade;
	private String valor;
	private String representacaocompleta;
	private String representacaoresumo;
}
