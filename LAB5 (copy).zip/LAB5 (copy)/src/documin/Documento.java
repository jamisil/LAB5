package documin;

import java.sql.Array;
import java.util.ArrayList;
//import java.util.Arrays;
import java.util.Objects;

public class Documento {
	private String titulo;
	private int tamanho;
	private ArrayList<Elemento> elementos;
	// public ElementoController elementocontroller;

	public Documento(String titulo) {
		if (titulo == null || titulo.isEmpty()) {
			throw new IllegalArgumentException();
		}
		this.titulo = titulo;
		this.elementos = new ArrayList<>();

	}

	public Documento(String titulo, int tamanhomaximo) {
		if (titulo == null || titulo.isEmpty()) {
			throw new IllegalArgumentException();
		} else if (tamanhomaximo <= 0) {
			throw new IllegalArgumentException();
		}
		this.titulo = titulo;
		this.tamanho = tamanhomaximo;
		this.elementos = new ArrayList<>(tamanho);
	}

	public int getnumeroelementos() {
		return elementos.size();
	}

	public void adicionaelemento(Elemento elemento) {
		this.elementos.add(elemento);
	}

	@Override
	public int hashCode() {
		return Objects.hash(titulo);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Documento other = (Documento) obj;
		return Objects.equals(titulo, other.titulo);
	}

	@Override
	public String toString() { // array de string
		// String representacao = "";
		return this.elementos.toString();

	}

	public String[] representacaoDocumento() {
		//resolver a representação 
	}

	public ArrayList<Elemento> getelementos() {
		return this.elementos;
	}

	public int criaElemento() {

		return getnumeroelementos;

	}

	public void moverelementoposicaoacima(int posicaoelemento) {
		// ***

	}

	public void moverelementoposicaoabaixo(int posicaoelemento) {
		// **
	}

	public void apagarelementoDocumento(int posicaoelemento) {

	}

}
