package documin;

import java.util.ArrayList;

public class Lista {
//	private String tituloDoc;
	private String valorLista;
	private int prioridade;
	private String separador;
	private String charLista;
	
	public Lista(String valorLista,int prioridade,String separador,String charLista) {
		this.valorLista = valorLista;
		this.prioridade = prioridade;
		this.separador = separador;
		this.charLista = charLista;
	}
	public String representacaocompleta() {
		String representacaocompleta = this.charLista + " ";
		representacaocompleta += this.valorLista.replace(separador,"\n-");
		return representacaocompleta;}
	public String representacaoresumida() {
		String representacaoresumida = "";
		String representacao = this.valorLista.replace(" ", "");
		representacaoresumida += representacao.replace(separador, ",");
		return representacaoresumida;
	}
}
