package documin;

import java.util.HashMap;

public class Titulo {
	//private String tituloDoc;
	private String valor;
//não tem propriedade	private HashMap<String,String> propriedade;
	private int nivel;
	private boolean linkavel;
	
	public Titulo( String valor, int nivel, boolean linkavel) {
		this.valor = valor;
		this.nivel = nivel;
		this.linkavel = linkavel;
		
	}
	public String representacaoCompleta() {
		String link = this.nivel + this.valor;
		if (this.linkavel == true) {
			 link = this.nivel + "-" + this.valor.toUpperCase().replace(" ", "");
			 return this.nivel + "." + this.valor + "--" + link;
		}
		return this.nivel  + this.valor + "--" ; 
	}
	
	public String representacaoResumida() {
		return this.nivel + "." + this.valor;
	}
}
