package documin;

public class Texto {
	//private  String tituloDoc;
	private String valor;
//	private int propriedade;
	
	public Texto(String valor) {
		this.valor = valor;
	}
	
	public String representacaoCompleta() {
		return this.valor;
	}
	
	public String representacaoResumida() {
		return this.valor;
	}
}
