package documin;

public class teste {

	public static void main(String[] args) {
		DocumentoController doc = new DocumentoController();
		Titulo t = new Titulo("Documentos Texto",1,true);
		System.out.println(t.representacaoCompleta());
		Texto tr = new Texto("string");
		System.out.println(tr.representacaoResumida());
		Lista l = new Lista("Exemplo | de uma lista | de 3 termos",2,"|","-");
		System.out.println(l.representacaocompleta());
		System.out.println(l.representacaoresumida());
		Termos e = new Termos("Teste / termos / Aleatórios","/","ALFABÉTICA");
		System.out.println(e.representacaoCompleta());


		

	}

}
