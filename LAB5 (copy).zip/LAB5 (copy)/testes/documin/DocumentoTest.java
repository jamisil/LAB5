package documin;

//import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class DocumentoTest {
	private DocumentoController sistema;
	private Documento doc;
	@BeforeEach
	void setUp() {
		DocumentoController sistema = new DocumentoController(); 
	}

	@Test
	void criaDocumentosemtamanho() {
		Facade f = new Facade();
		Documento doc = new Documento("Linda");
		assertEquals("",doc.toString());
	}
	@Test
	void numeroelemento() {
		Documento doc = new Documento("facas",8);
		assertEquals(0,doc.getnumeroelementos);
	}
	@Test
	void numeroelementoadiciona() {
		Documento doc = new Documento("facas");
		assertEquals("[]",doc.toString());
	}

}
